package net.skyz.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.PlayerInput;

/**
 * Central state for all built-in mod toggles.
 * tick() is called every game tick from SkyzClientMod's ClientTickEvents.
 */
public final class SkyzClientState {
    private SkyzClientState() {}

    // CPS tracking - ring buffer
    public static int cps = 0;
    private static final long[] CPS_CLICKS = new long[20];
    private static int cpsHead = 0;

    public static void recordClick() {
        CPS_CLICKS[cpsHead % 20] = System.currentTimeMillis();
        cpsHead++;
    }

    public static void updateCps() {
        long now = System.currentTimeMillis();
        int count = 0;
        for (long t : CPS_CLICKS) if (t > 0 && now - t < 1000) count++;
        cps = count;
    }

    // QoL Toggles
    public static boolean toggleSprint    = false;
    public static boolean toggleSneak     = false;
    public static boolean toggleChat      = true;
    public static boolean fullbright      = false;
    public static boolean noFog           = false;
    public static boolean noPumpkinBlur   = false;
    public static boolean antiAfk         = false;
    public static boolean autoGG          = false;

    // Visual toggles
    public static float   fovMultiplier   = 1.0f;
    public static boolean coloredHitboxes = false;
    public static boolean noFireOverlay   = false;

    // \u2500\u2500 Hacks \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    public static boolean storageEsp        = false;
    public static boolean playerEsp         = false;
    public static boolean itemEsp           = false; // item hitboxes through walls
    public static boolean blockEsp          = false; // configurable in settings
    public static boolean autoTotem         = false;
    public static boolean trajectories      = false; // bow/pearl paths
    public static boolean mobEsp            = false;
    public static boolean oreHighlighter    = false;
    public static boolean autoclicker       = false;
    public static int     autoclickerCps    = 12;    // target CPS
    public static boolean dynamicFps        = false; // limit FPS when tabbed/AFK
    public static boolean particleLimiter   = false;
    public static boolean chatTimestamps    = true;
    public static long    sessionStartMs    = System.currentTimeMillis();

    // Minimap settings (persisted via SkyzConfig)
    public static boolean minimapShowLeaves  = false; // false = use MOTION_BLOCKING_NO_LEAVES
    public static boolean minimapCaveMode    = true;  // true = show cave below player
    public static boolean minimapShowEntities= true;
    public static int     minimapZoom        = 32;    // range in blocks each side

    // Anti-AFK state
    private static int  afkTick     = 0;
    private static boolean afkDir   = false;

    // Combo counter
    public static int  comboCount   = 0;
    public static long lastHitTime  = 0;
    private static final long COMBO_RESET_MS = 3500;

    // Totem pop counter
    public static int totemPops = 0;

    /**
     * Called every game tick from SkyzClientMod.
     */
    public static void tick(MinecraftClient client) {
        if (client.player == null) return;

        // Fullbright: set gamma to maximum each tick
        if (fullbright) {
            try {
                // In 1.21.11, SimpleOption<Double> stores value in field named "value"
                // setValue() is clamped to [0,1], so we write the backing field directly
                var gammaOpt = client.options.getGamma();
                gammaOpt.setValue(1.0); // set to max vanilla first
                // Now force the backing "value" field past the clamp
                for (var f : gammaOpt.getClass().getDeclaredFields()) {
                    f.setAccessible(true);
                    try {
                        Object current = f.get(gammaOpt);
                        if (current instanceof Double) {
                            f.set(gammaOpt, 100.0);
                            break;
                        }
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
        }

        // Toggle sprint
        if (toggleSprint && client.options.forwardKey.isPressed()) {
            client.player.setSprinting(true);
        }

        // Toggle sneak - hold sneak state persistently when toggle is ON
        // The user disables this from the Built-in Mods tab in the HUD editor.
        if (toggleSneak) {
            client.player.setSneaking(true);
            PlayerInput current = client.player.input.playerInput;
            client.player.input.playerInput = new PlayerInput(
                current.forward(),
                current.backward(),
                current.left(),
                current.right(),
                current.jump(),
                true,
                current.sprint()
            );
        }

        // Anti-AFK - jump every 30 seconds
        if (antiAfk) {
            afkTick++;
            if (afkTick >= 600) {
                afkTick = 0;
                if (client.player.isOnGround()) client.player.jump();
            }
        }

        // Combo reset after 3.5s
        if (comboCount > 0 && System.currentTimeMillis() - lastHitTime > COMBO_RESET_MS) {
            comboCount = 0;
        }
    }

    /** Called when player lands a hit (detected by tracking attack key presses in game). */
    public static void registerHit() {
        comboCount++;
        lastHitTime = System.currentTimeMillis();
    }

    /** Called when player uses a totem of undying. */
    public static void registerTotemPop() {
        totemPops++;
    }
}