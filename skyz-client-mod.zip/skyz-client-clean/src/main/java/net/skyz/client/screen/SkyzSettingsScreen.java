package net.skyz.client.screen;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.skyz.client.util.*;
import net.skyz.client.util.SkyzConfig;
import net.skyz.client.util.SkyzClientState;

/**
 * Skyz Settings - scrollable, with themes, interface toggles, sliders,
 * minimap settings, and client info.
 */
public class SkyzSettingsScreen extends Screen {

    private final SkyzTitleScreen parent;

    private final boolean[] toggles = {true, false, true, true, false};
    private final int[]     sliders = {20, 70, 60, 100};

    private int  draggingSlider = -1;
    private int  sliderStartX;

    // Scroll state
    private int  scrollY    = 0;
    private int  maxScrollY = 0; // computed each render

    private static final int NAV_H  = 30;
    private static final int PAD    = 14;
    private static final int ROW_H  = 26;
    private static final int SCROLL_BAR_W = 6;

    public SkyzSettingsScreen(SkyzTitleScreen parent) {
        super(Text.literal("Skyz Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addDrawableChild(SkyzButton.of(width - 82, 7, 74, 18, "\u2190 Back",
                () -> client.setScreen(parent)));
        scrollY = 0;
    }

    // \u2500\u2500 Render \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Background
        SkyzRenderHelper.fillGradientV(ctx, 0, 0, width, height / 3,
                SkyzTheme.BG1, SkyzTheme.BG2);
        SkyzRenderHelper.fillGradientV(ctx, 0, height / 3, width, height * 2 / 3,
                SkyzTheme.BG2, SkyzTheme.BG3);
        SkyzRenderHelper.fillGradientV(ctx, 0, height * 2 / 3, width, height / 3,
                SkyzTheme.BG3, SkyzTheme.BG1);

        drawNavBar(ctx);

        // Clip scrollable content below the nav bar
        ctx.enableScissor(0, NAV_H, width - SCROLL_BAR_W - 2, height);

        int y = NAV_H + 10 - scrollY;

        y = drawSectionHeader(ctx, "Theme", y);
        y = drawThemeGrid(ctx, y, mouseX, mouseY + scrollY);

        y = drawSectionHeader(ctx, "Interface", y + 10);
        y = drawToggles(ctx, y, mouseX, mouseY + scrollY);
        y = drawSliders(ctx, y, mouseX, mouseY + scrollY);

        y = drawSectionHeader(ctx, "Minimap & ESP", y + 10);
        y = drawMinimapSettings(ctx, y, mouseX, mouseY + scrollY);

        y = drawSectionHeader(ctx, "Client Info", y + 10);
        drawClientInfo(ctx, y);
        y += 7 * 24 + 10; // 7 info rows

        ctx.disableScissor();

        // Compute and clamp max scroll
        int contentH = (y + scrollY) - (NAV_H + 10);
        maxScrollY = Math.max(0, contentH - (height - NAV_H - 10));
        scrollY = Math.max(0, Math.min(maxScrollY, scrollY));

        // Scrollbar
        if (maxScrollY > 0) {
            int sbH   = height - NAV_H;
            int thumbH = Math.max(20, sbH * sbH / (contentH));
            int thumbY = NAV_H + (int)((long) scrollY * (sbH - thumbH) / maxScrollY);
            ctx.fill(width - SCROLL_BAR_W - 1, NAV_H, width - 1, height, 0x22FFFFFF);
            ctx.fill(width - SCROLL_BAR_W - 1, thumbY, width - 1, thumbY + thumbH, 0x888CD2FF);
        }

        // Nav bar drawn on top so it's never clipped
        drawNavBar(ctx);

        super.render(ctx, mouseX, mouseY, delta);
        parent.toast.render(ctx, width, delta);
    }

    // \u2500\u2500 Draw helpers \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

    private void drawNavBar(DrawContext ctx) {
        // Solid backing so content doesn't bleed through
        ctx.fill(0, 0, width, NAV_H, 0xCC000000 | (SkyzTheme.BG1 & 0x00FFFFFF));
        ctx.drawTextWithShadow(textRenderer, "SKYZ", 10, 10, 0xFFF0F8FF);
        int x = 10 + textRenderer.getWidth("SKYZ") + 6;
        ctx.drawTextWithShadow(textRenderer, "/", x, 10, SkyzTheme.ACCENT_DIM);
        x += textRenderer.getWidth("/") + 6;
        ctx.drawTextWithShadow(textRenderer, "SETTINGS", x, 10, 0x888CD2FF);
        SkyzRenderHelper.drawDivider(ctx, 0, NAV_H, width);
    }

    private int drawSectionHeader(DrawContext ctx, String title, int y) {
        if (y > height || y + 20 < NAV_H) return y + 20; // offscreen fast-path
        ctx.drawTextWithShadow(textRenderer, title.toUpperCase(), PAD, y, SkyzTheme.ACCENT_DIM);
        SkyzRenderHelper.fillRect(ctx, PAD, y + 11, width - PAD * 2 - SCROLL_BAR_W - 2, 1, SkyzTheme.DIVIDER);
        return y + 20;
    }

    private int drawThemeGrid(DrawContext ctx, int y, int mx, int my) {
        int cols = SkyzTheme.THEMES.length;
        int cw   = (width - PAD * 2 - (cols - 1) * 6 - SCROLL_BAR_W - 2) / cols;
        int ch   = 48;
        if (y + ch >= NAV_H && y < height) {
            for (int i = 0; i < SkyzTheme.THEMES.length; i++) {
                int tx = PAD + i * (cw + 6);
                boolean sel = i == SkyzTheme.getCurrent();
                boolean hov = mx >= tx && mx <= tx + cw && my >= y && my <= y + ch;
                String[] t = SkyzTheme.THEMES[i];
                int c1 = (int) Long.parseLong(t[1].substring(2), 16);
                int c2 = (int) Long.parseLong(t[3].substring(2), 16);
                int ac = (int) Long.parseLong(t[5].substring(2), 16);
                SkyzRenderHelper.fillGradientV(ctx, tx, y, cw, ch, c1, c2);
                int brdCol = sel ? (ac | 0xFF000000) : hov ? ((ac & 0x00FFFFFF) | 0x88000000) : ((ac & 0x00FFFFFF) | 0x33000000);
                SkyzRenderHelper.fillRect(ctx, tx, y, cw, 2, sel ? (ac | 0xFF000000) : (ac & 0x00FFFFFF) | (hov ? 0x99000000 : 0x44000000));
                SkyzRenderHelper.fillRect(ctx, tx, y, cw, 1, brdCol);
                SkyzRenderHelper.fillRect(ctx, tx, y+ch-1, cw, 1, brdCol);
                SkyzRenderHelper.fillRect(ctx, tx, y, 1, ch, brdCol);
                SkyzRenderHelper.fillRect(ctx, tx+cw-1, y, 1, ch, brdCol);
                if (sel) ctx.drawCenteredTextWithShadow(textRenderer, "\u2713", tx + cw/2, y + 8, 0xFFFFFFFF);
                SkyzRenderHelper.fillRect(ctx, tx + cw/2 - 4, y + 20, 8, 8, (ac | 0xFF000000));
                ctx.drawCenteredTextWithShadow(textRenderer, t[0], tx + cw/2, y + ch - 14, 0xCCFFFFFF);
            }
        }
        return y + ch + 8;
    }

    private int drawToggles(DrawContext ctx, int y, int mx, int my) {
        String[][] rows = {
            {"Particle Effects", "Ambient floating particles"},
            {"Splash Text",      "Rotating tip on title screen"},
            {"Animations",       "Hover & transition effects"},
            {"Glow Effects",     "Accent glow on panels"},
            {"Compact Mode",     "Smaller cards in lists"},
        };
        int halfW = (width - PAD * 2 - SCROLL_BAR_W - 2) / 2 - 8;
        for (int i = 0; i < rows.length; i++) {
            int col = i % 2, row = i / 2;
            int rx = PAD + col * (halfW + 16);
            int ry = y + row * ROW_H;
            if (ry + ROW_H < NAV_H || ry > height) continue;
            SkyzRenderHelper.fillRect(ctx, rx, ry, halfW, ROW_H - 2, 0x1A091E46);
            ctx.drawTextWithShadow(textRenderer, rows[i][0], rx + 8, ry + 5, SkyzColors.TEXT_PRIMARY);
            ctx.drawTextWithShadow(textRenderer, rows[i][1], rx + 8, ry + 15, SkyzColors.TEXT_MUTED & 0x88FFFFFF | (SkyzColors.TEXT_MUTED & 0xFF000000) >> 1);
            boolean on = i < toggles.length && toggles[i];
            int tx = rx + halfW - 44, ty = ry + (ROW_H-2)/2 - 7;
            SkyzRenderHelper.fillPanel(ctx, tx, ty, 38, 14, on ? 0x55143C8A : 0x33143254, on ? SkyzTheme.ACCENT_DIM : 0x2A8CD2FF);
            SkyzRenderHelper.fillRect(ctx, on ? tx+23 : tx+3, ty+3, 10, 8, on ? (SkyzTheme.ACCENT1|0xFF000000) : 0x7890AACC);
        }
        int rowsUsed = (rows.length + 1) / 2;
        return y + rowsUsed * ROW_H + 6;
    }

    private int drawSliders(DrawContext ctx, int y, int mx, int my) {
        String[][] defs = {{"Blur Intensity","0","40","px"},{"Glow Strength","0","100","%"},{"Particle Count","0","100","%"}};
        int sW = 160;
        for (int i = 0; i < defs.length; i++) {
            if (y + ROW_H >= NAV_H && y < height) {
                SkyzRenderHelper.fillRect(ctx, PAD, y, width - PAD*2 - SCROLL_BAR_W - 2, ROW_H-2, 0x1A091E46);
                ctx.drawTextWithShadow(textRenderer, defs[i][0], PAD+8, y+9, SkyzColors.TEXT_PRIMARY);
                int max = Integer.parseInt(defs[i][2]);
                String val = sliders[i] + defs[i][3];
                ctx.drawTextWithShadow(textRenderer, val, width-PAD-sW-textRenderer.getWidth(val)-10-SCROLL_BAR_W-2, y+9, SkyzColors.TEXT_MUTED);
                int sX = width-PAD-sW-4-SCROLL_BAR_W-2, sY = y+(ROW_H-2)/2;
                float pct = (float) sliders[i] / max;
                SkyzRenderHelper.fillRect(ctx, sX, sY-2, sW, 4, SkyzTheme.DIVIDER);
                SkyzRenderHelper.fillRect(ctx, sX, sY-2, (int)(sW*pct), 4, SkyzTheme.ACCENT_DIM);
                int kx = sX+(int)(sW*pct)-5;
                boolean hov = mx>=kx&&mx<=kx+10&&my>=sY-6&&my<=sY+6;
                SkyzRenderHelper.fillPanel(ctx, kx, sY-5, 10, 10, hov?SkyzTheme.BTN_BG:0x88143C6E, hov?(SkyzTheme.ACCENT1|0xFF000000):(SkyzTheme.ACCENT2|0xFF000000));
            }
            y += ROW_H;
        }
        return y + 4;
    }

    private int drawMinimapSettings(DrawContext ctx, int y, int mx, int my) {
        int halfW = (width - PAD*2 - SCROLL_BAR_W - 2) / 2 - 8;
        int[] cols = {PAD, PAD + halfW + 16};
        String[] labels1 = {"Cave Mode", "Show Leaves"};
        boolean[] vals1 = {SkyzClientState.minimapCaveMode, SkyzClientState.minimapShowLeaves};
        for (int i = 0; i < 2; i++) {
            if (y+ROW_H >= NAV_H && y < height) {
                SkyzRenderHelper.fillRect(ctx, cols[i], y, halfW, ROW_H-2, 0x1A091E46);
                ctx.drawTextWithShadow(textRenderer, labels1[i], cols[i]+8, y+9, SkyzColors.TEXT_PRIMARY);
                boolean on = vals1[i];
                int tx = cols[i]+halfW-44, ty = y+(ROW_H-2)/2-7;
                SkyzRenderHelper.fillPanel(ctx, tx, ty, 36, 14, on?0x551E6EC8:0x33143254, on?0x6464BEFF:0x2A8CD2FF);
                SkyzRenderHelper.fillRect(ctx, on?tx+21:tx+3, ty+3, 10, 8, on?0xCC64C8FF:0x7890AACC);
            }
        }
        y += ROW_H;
        String[] labels2 = {"Show Entities", "Storage ESP"};
        boolean[] vals2 = {SkyzClientState.minimapShowEntities, SkyzClientState.storageEsp};
        for (int i = 0; i < 2; i++) {
            if (y+ROW_H >= NAV_H && y < height) {
                SkyzRenderHelper.fillRect(ctx, cols[i], y, halfW, ROW_H-2, 0x1A091E46);
                ctx.drawTextWithShadow(textRenderer, labels2[i], cols[i]+8, y+9, SkyzColors.TEXT_PRIMARY);
                boolean on = vals2[i];
                int tx = cols[i]+halfW-44, ty = y+(ROW_H-2)/2-7;
                SkyzRenderHelper.fillPanel(ctx, tx, ty, 36, 14, on?0x551E6EC8:0x33143254, on?0x6464BEFF:0x2A8CD2FF);
                SkyzRenderHelper.fillRect(ctx, on?tx+21:tx+3, ty+3, 10, 8, on?0xCC64C8FF:0x7890AACC);
            }
        }
        y += ROW_H;
        // Zoom slider
        if (y+ROW_H >= NAV_H && y < height) {
            int w = width - PAD*2 - SCROLL_BAR_W - 2;
            SkyzRenderHelper.fillRect(ctx, PAD, y, w, ROW_H-2, 0x1A091E46);
            ctx.drawTextWithShadow(textRenderer, "Minimap Zoom", PAD+8, y+9, SkyzColors.TEXT_PRIMARY);
            int sW = 160, sX = width-PAD-sW-4-SCROLL_BAR_W-2, sY = y+(ROW_H-2)/2;
            SkyzRenderHelper.fillRect(ctx, sX, sY-2, sW, 4, 0x338CD2FF);
            int filled = (SkyzClientState.minimapZoom-16)*sW/(96-16);
            SkyzRenderHelper.fillRect(ctx, sX, sY-2, filled, 4, 0x9964C8FF);
            ctx.drawTextWithShadow(textRenderer, SkyzClientState.minimapZoom+" blk",
                    sX-textRenderer.getWidth(SkyzClientState.minimapZoom+" blk")-6, y+9, SkyzColors.TEXT_MUTED);
        }
        y += ROW_H;
        return y + 6;
    }

    private void drawClientInfo(DrawContext ctx, int y) {
        String[][] info = {
            {"Skyz Client",   "v3.0.2"},
            {"Minecraft",     "1.21.11"},
            {"Fabric Loader", getModVersion("fabricloader","0.16.10")},
            {"Sodium",        getModVersion("sodium","not installed")},
            {"Iris Shaders",  getModVersion("iris","not installed")},
            {"Mod Menu",      getModVersion("modmenu","not installed")},
            {"Essential",     getModVersion("essential","not installed")},
        };
        for (String[] row : info) {
            if (y+22 >= NAV_H && y < height) {
                boolean ok = !row[1].equals("not installed");
                SkyzRenderHelper.fillRect(ctx, PAD, y, width-PAD*2-SCROLL_BAR_W-2, 22, 0x1A091E46);
                ctx.drawTextWithShadow(textRenderer, row[0], PAD+8, y+7, SkyzColors.TEXT_MUTED);
                int col = ok ? SkyzColors.TEXT_PRIMARY : 0x66888888;
                ctx.drawTextWithShadow(textRenderer, row[1], width-PAD-textRenderer.getWidth(row[1])-8-SCROLL_BAR_W-2, y+7, col);
                int dot = ok ? SkyzColors.STATUS_GREEN : SkyzColors.STATUS_RED;
                SkyzRenderHelper.fillRect(ctx, width-PAD-textRenderer.getWidth(row[1])-18-SCROLL_BAR_W-2, y+10, 6, 6, dot);
            }
            y += 24;
        }
    }

    private String getModVersion(String id, String fallback) {
        return net.fabricmc.loader.api.FabricLoader.getInstance()
                .getModContainer(id).map(m -> m.getMetadata().getVersion().getFriendlyString())
                .orElse(fallback);
    }

    // \u2500\u2500 Y-position helpers (account for scroll) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    private int themeGridTop()  { return NAV_H + 10 + 20 - scrollY; }
    private int togglesTop()    { return themeGridTop() + 48 + 8 + 10 + 20; }
    private int slidersTop()    { return togglesTop() + ((5+1)/2) * ROW_H + 6; }
    private int minimapBaseY()  { return slidersTop() + 3*ROW_H + 4 + 10 + 20; }

    // \u2500\u2500 Input \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

    @Override
    public boolean mouseScrolled(double mx, double my, double horiz, double vert) {
        scrollY = Math.max(0, Math.min(maxScrollY, scrollY - (int)(vert * 20)));
        return true;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) return true;
        double mx = click.x(), my = click.y();
        // All hit tests use scrolled coordinates
        double smy = my + scrollY;

        // Theme grid
        int cols = SkyzTheme.THEMES.length;
        int cw = (width-PAD*2-(cols-1)*6-SCROLL_BAR_W-2)/cols, ch = 48;
        int themeY = themeGridTop() + scrollY; // unscrolled Y
        for (int i = 0; i < SkyzTheme.THEMES.length; i++) {
            int tx = PAD + i*(cw+6);
            if (mx>=tx&&mx<=tx+cw&&smy>=themeY&&smy<=themeY+ch) {
                SkyzTheme.apply(i); parent.toast("Theme: "+SkyzTheme.THEMES[i][0]); SkyzConfig.save(); return true;
            }
        }

        // Toggles
        int toggleY = togglesTop() + scrollY;
        int halfW = (width-PAD*2-SCROLL_BAR_W-2)/2-8;
        for (int i = 0; i < 5; i++) {
            int col=i%2, row=i/2;
            int rx=PAD+col*(halfW+16), ry=toggleY+row*ROW_H;
            int tx=rx+halfW-44, ty=ry+(ROW_H-2)/2-7;
            if (mx>=tx&&mx<=tx+38&&smy>=ty&&smy<=ty+14) {
                if (i<toggles.length) { toggles[i]=!toggles[i]; applyToggle(i); } return true;
            }
        }

        // Sliders
        int sliderY = slidersTop() + scrollY;
        int sW=160, sX=width-PAD-sW-4-SCROLL_BAR_W-2;
        int[] maxes = {40,100,100};
        for (int i = 0; i < 3; i++) {
            int sy = sliderY+(ROW_H-2)/2;
            if (mx>=sX&&mx<=sX+sW&&smy>=sy-10&&smy<=sy+10) {
                draggingSlider=i; sliderStartX=sX;
                sliders[i]=Math.max(0,Math.min(maxes[i],(int)((mx-sX)/sW*maxes[i])));
                applySlider(i); return true;
            }
            sliderY+=ROW_H;
        }

        // Minimap toggles
        int mapBaseY = minimapBaseY() + scrollY;
        int mhW = (width-PAD*2-SCROLL_BAR_W-2)/2-8;
        int[] mCols = {PAD, PAD+mhW+16};
        for (int row = 0; row < 2; row++) {
            int rowY = mapBaseY+row*ROW_H;
            for (int col = 0; col < 2; col++) {
                int tx=mCols[col]+mhW-44, ty=rowY+(ROW_H-2)/2-7;
                if (mx>=tx&&mx<=tx+36&&smy>=ty&&smy<=ty+14) {
                    switch (row*2+col) {
                        case 0 -> { SkyzClientState.minimapCaveMode   =!SkyzClientState.minimapCaveMode;   net.skyz.client.util.SkyzMinimapState.invalidate(); SkyzConfig.save(); }
                        case 1 -> { SkyzClientState.minimapShowLeaves =!SkyzClientState.minimapShowLeaves; net.skyz.client.util.SkyzMinimapState.invalidate(); SkyzConfig.save(); }
                        case 2 -> { SkyzClientState.minimapShowEntities =!SkyzClientState.minimapShowEntities; SkyzConfig.save(); }
                        case 3 -> { SkyzClientState.storageEsp =!SkyzClientState.storageEsp; SkyzConfig.save(); }
                    }
                    return true;
                }
            }
        }
        // Zoom slider
        int zoomY = mapBaseY+2*ROW_H;
        int zSW=160, zSX=width-PAD-zSW-4-SCROLL_BAR_W-2, zSY=zoomY+(ROW_H-2)/2;
        if (mx>=zSX&&mx<=zSX+zSW&&smy>=zSY-8&&smy<=zSY+8) {
            int val=16+(int)((mx-zSX)/zSW*(96-16));
            SkyzClientState.minimapZoom=Math.max(16,Math.min(96,val));
            net.skyz.client.util.SkyzMinimapState.invalidate(); SkyzConfig.save(); return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (draggingSlider >= 0) {
            int sW=160, sX=width-PAD-sW-4-SCROLL_BAR_W-2;
            int[] maxes={40,100,100};
            sliders[draggingSlider]=Math.max(0,Math.min(maxes[draggingSlider],
                    (int)((click.x()-sX)/sW*maxes[draggingSlider])));
            applySlider(draggingSlider); return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) { draggingSlider=-1; return super.mouseReleased(click); }

    private void applyToggle(int i) {
        if (i==0) parent.particles.setEnabled(toggles[0]);
        SkyzConfig.save();
    }
    private void applySlider(int i) { SkyzConfig.save(); }

    @Override public boolean shouldPause() { return false; }
}
