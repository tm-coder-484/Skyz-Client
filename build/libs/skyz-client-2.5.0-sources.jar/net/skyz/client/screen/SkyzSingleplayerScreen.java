package net.skyz.client.screen;

import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_34;
import net.minecraft.class_437;
import net.minecraft.class_526;
import net.skyz.client.util.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Custom Singleplayer screen using MC's actual world list.
 *
 * 1.21.11 API notes:
 *  - LevelSummary.getDisplayName() returns String directly
 *  - LevelSummary.getGameMode() returns GameMode enum - compare with == GameMode.CREATIVE etc.
 *  - LevelStorage.loadSummaries() takes a LevelStorage.LevelList, obtained via getLevelList()
 *  - client field is protected in Screen; store reference in constructor
 *  - World loading via SelectWorldScreen for reliability
 */
public class SkyzSingleplayerScreen extends class_437 {

    private final SkyzTitleScreen parent;
    private final class_310 mc;

    private List<class_34> worlds   = new ArrayList<>();
    private boolean            loaded   = false;
    private boolean            failed   = false;

    private String searchQuery  = "";
    private String activeFilter = "all";
    private int    scrollOffset = 0;

    private static final int NAV_H     = 30;
    private static final int TOOLBAR_H = 28;
    private static final int CARD_H    = 72;
    private static final int CARD_GAP  = 6;
    private static final int PAD       = 12;

    public SkyzSingleplayerScreen(SkyzTitleScreen parent) {
        super(class_2561.method_43470("Singleplayer"));
        this.parent = parent;
        this.mc     = class_310.method_1551();
        loadWorlds();
    }

    private void loadWorlds() {
        try {
            // getLevelList() returns the list of saved worlds in 1.21.11
            var list = mc.method_1586().method_235();
            worlds = mc.method_1586().method_43417(list).join();
            loaded = true;
        } catch (Exception e) {
            net.skyz.client.SkyzClientMod.LOGGER.warn("[Skyz] World load failed: {}", e.getMessage());
            failed = true;
        }
    }

    @Override
    protected void method_25426() {
        method_37063(SkyzButton.of(field_22789 - 82, 7, 74, 18, "\u2190 Back",
                () -> field_22787.method_1507(parent)));
        method_37063(SkyzButton.of(PAD, NAV_H + 4, 130, 20, "+ Create World",
                () -> field_22787.method_1507(new class_526(this))));
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        SkyzRenderHelper.fillGradientV(ctx, 0, 0, field_22789, field_22790, SkyzTheme.BG1, SkyzTheme.BG2);
        drawNavBar(ctx);
        drawToolbar(ctx, mouseX, mouseY);

        if (failed) {
            ctx.method_25300(field_22793,
                    "Could not load worlds. Click to open vanilla world selector.",
                    field_22789 / 2, field_22790 / 2 - 14, SkyzColors.TEXT_MUTED);
            method_37063(SkyzButton.of(field_22789 / 2 - 100, field_22790 / 2 + 4, 200, 20,
                    "\uD83C\uDF0D Open World Selection",
                    () -> field_22787.method_1507(new class_526(this))));
        } else if (!loaded) {
            ctx.method_25300(field_22793,
                    "Loading worlds...", field_22789 / 2, field_22790 / 2, SkyzColors.TEXT_MUTED);
        } else {
            drawWorldList(ctx, mouseX, mouseY);
        }

        super.method_25394(ctx, mouseX, mouseY, delta);
        parent.toast.render(ctx, field_22789, delta);
    }

    private void drawNavBar(class_332 ctx) {
        ctx.method_25303(field_22793, "SKYZ", 10, 10, 0xFFF0F8FF);
        int x = 10 + field_22793.method_1727("SKYZ") + 6;
        ctx.method_25303(field_22793, "/", x, 10, 0x4D8CD2FF);
        x += field_22793.method_1727("/") + 6;
        ctx.method_25303(field_22793, "SINGLEPLAYER", x, 10, 0x888CD2FF);
        SkyzRenderHelper.drawDivider(ctx, 0, NAV_H, field_22789);
    }

    private void drawToolbar(class_332 ctx, int mx, int my) {
        int ty = NAV_H + 4;
        int sX = PAD + 138, sW = Math.min(220, field_22789 - sX - PAD - 80);
        SkyzRenderHelper.fillPanel(ctx, sX, ty, sW, 20, 0x55091E46, 0x338CD2FF);
        String q = searchQuery.isEmpty() ? "Search worlds..." : searchQuery;
        ctx.method_25303(field_22793, q, sX + 6, ty + 6,
                searchQuery.isEmpty() ? 0x388CD2FF : SkyzColors.TEXT_PRIMARY);

        int fx = sX + sW + 8;
        for (String[] f : new String[][]{{"all","All"},{"survival","Survival"},{"creative","Creative"},{"hardcore","Hardcore"}}) {
            boolean active = activeFilter.equals(f[0]);
            int fw = field_22793.method_1727(f[1]) + 14;
            SkyzRenderHelper.fillPanel(ctx, fx, ty, fw, 20,
                    active ? 0x553C6E90 : 0x33091E46, active ? 0x998CD2FF : 0x338CD2FF);
            ctx.method_25303(field_22793, f[1], fx + 7, ty + 6,
                    active ? 0xFFFFFFFF : SkyzColors.TEXT_MUTED);
            fx += fw + 4;
        }

        List<class_34> vis = getFiltered();
        String cnt = vis.size() + " world" + (vis.size() == 1 ? "" : "s");
        ctx.method_25303(field_22793, cnt, field_22789 - PAD - field_22793.method_1727(cnt), ty + 6, 0x4D8CD2FF);
    }

    private void drawWorldList(class_332 ctx, int mx, int my) {
        List<class_34> filtered = getFiltered();
        int listTop = NAV_H + TOOLBAR_H + 8;
        int listH   = field_22790 - listTop - 8;
        int cardW   = field_22789 - PAD * 2;
        int y       = listTop - scrollOffset;

        ctx.method_44379(0, listTop, field_22789, field_22790 - 8);
        for (class_34 w : filtered) {
            if (y + CARD_H >= listTop && y <= listTop + listH)
                drawCard(ctx, w, PAD, y, cardW, CARD_H, mx, my);
            y += CARD_H + CARD_GAP;
        }
        ctx.method_44380();

        if (filtered.isEmpty() && loaded) {
            int cY = NAV_H + TOOLBAR_H + 8 + (field_22790 - NAV_H - TOOLBAR_H - 16) / 2;
            ctx.method_25300(field_22793,
                    searchQuery.isEmpty() ? "No worlds yet. Create one!" : "No worlds match \"" + searchQuery + "\"",
                    field_22789 / 2, cY, SkyzColors.TEXT_MUTED);
        }

        // Scrollbar
        int totalH = filtered.size() * (CARD_H + CARD_GAP);
        if (totalH > listH && filtered.size() > 0) {
            SkyzRenderHelper.fillRect(ctx, field_22789 - 4, listTop, 3, listH, 0x1A8CD2FF);
            int th  = Math.max(20, (int)((float) listH / totalH * listH));
            int ty2 = listTop + (int)((float) scrollOffset / Math.max(1, totalH - listH) * (listH - th));
            SkyzRenderHelper.fillRect(ctx, field_22789 - 4, ty2, 3, th, 0x558CD2FF);
        }
    }

    private void drawCard(class_332 ctx, class_34 w,
                          int x, int y, int ww, int h, int mx, int my) {
        boolean hov = mx >= x && mx <= x + ww && my >= y && my <= y + h;
        SkyzRenderHelper.fillPanel(ctx, x, y, ww, h,
                hov ? 0x800C2A5A : SkyzColors.CARD_BG, hov ? 0x478CD2FF : SkyzColors.CARD_BORDER);

        // Icon based on game mode
        boolean hardcore = w.method_257();
        class_1934 gm = w.method_247();
        String emoji = hardcore ? "\uD83D\uDC80"
                : gm == class_1934.field_9220 ? "\uD83C\uDFD7"
                : gm == class_1934.field_9216 ? "\uD83D\uDDE1"
                : "\uD83C\uDF10";
        ctx.method_25303(field_22793, emoji, x + 12, y + (h - 8) / 2, 0xFFFFFFFF);

        int tx = x + 30;
        // getDisplayName() returns String in 1.21.11
        String displayName = w.method_252();
        ctx.method_25303(field_22793, displayName, tx, y + 8, SkyzColors.TEXT_PRIMARY);
        ctx.method_25303(field_22793, w.method_248(), tx, y + 20, 0x4D8CD2FF);

        // Last played
        String date = w.method_249() > 0
                ? new SimpleDateFormat("d MMM yyyy").format(new Date(w.method_249()))
                : "Unknown";
        String mode = getModeName(w);
        ctx.method_25303(field_22793, date + "  \u00B7  " + mode, tx, y + 32, 0x558CD2FF);

        // Mode tag
        int tagCol = hardcore ? 0x99FF4444
                : gm == class_1934.field_9220 ? 0x994DB4FF
                : 0x9944CC88;
        int tagW = field_22793.method_1727(mode) + 8;
        SkyzRenderHelper.fillPanel(ctx, tx, y + 46, tagW, 13,
                SkyzColors.withAlpha(tagCol, 0x22), SkyzColors.withAlpha(tagCol, 0x66));
        ctx.method_25303(field_22793, mode, tx + 4, y + 49, tagCol);

        // Buttons
        int bx = x + ww - 122, by = y + (h - 16) / 2;
        drawSmallBtn(ctx, "Play",   bx,      by, 52, 16, true,  mx, my);
        drawSmallBtn(ctx, "Edit",   bx + 56, by, 38, 16, false, mx, my);
        drawSmallBtn(ctx, "Del",    bx + 98, by, 30, 16, false, mx, my);
    }

    private String getModeName(class_34 w) {
        if (w.method_257()) return "Hardcore";
        class_1934 gm = w.method_247();
        if (gm == class_1934.field_9220)   return "Creative";
        if (gm == class_1934.field_9216)  return "Adventure";
        if (gm == class_1934.field_9219)  return "Spectator";
        return "Survival";
    }

    private void drawSmallBtn(class_332 ctx, String label, int x, int y, int w, int h,
                              boolean primary, int mx, int my) {
        boolean hov = mx >= x && mx <= x + w && my >= y && my <= y + h;
        SkyzRenderHelper.fillPanel(ctx, x, y, w, h,
                primary ? (hov ? 0x661E6EC8 : 0x441864A0) : (hov ? 0x66143C6E : 0x33091E46),
                primary ? 0x558CD2FF : 0x338CD2FF);
        ctx.method_25300(field_22793, label, x + w / 2, y + (h - 8) / 2,
                hov ? 0xFFFFFFFF : SkyzColors.TEXT_MUTED);
    }

    // \u2500\u2500 Input \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (super.method_25402(click, doubled)) return true;
        double mx = click.comp_4798(), my = click.comp_4799();

        // Filter buttons
        int ty = NAV_H + 4, sX = PAD + 138;
        int sW = Math.min(220, field_22789 - sX - PAD - 80);
        int fx = sX + sW + 8;
        for (String[] f : new String[][]{{"all","All"},{"survival","Survival"},{"creative","Creative"},{"hardcore","Hardcore"}}) {
            int fw = field_22793.method_1727(f[1]) + 14;
            if (mx >= fx && mx <= fx + fw && my >= ty && my <= ty + 20) {
                activeFilter = f[0]; scrollOffset = 0; return true;
            }
            fx += fw + 4;
        }

        // Card buttons
        if (loaded) {
            List<class_34> filtered = getFiltered();
            int listTop = NAV_H + TOOLBAR_H + 8;
            int cardW   = field_22789 - PAD * 2;
            int y       = listTop - scrollOffset;
            for (class_34 w : filtered) {
                int bx = PAD + cardW - 122, by = y + (CARD_H - 16) / 2;
                // Play
                if (mx >= bx && mx <= bx + 52 && my >= by && my <= by + 16) {
                    openWorld(w); return true;
                }
                // Edit
                if (mx >= bx+56 && mx <= bx+94 && my >= by && my <= by+16) {
                    parent.toast("Edit: " + w.method_252()); return true;
                }
                // Delete
                if (mx >= bx+98 && mx <= bx+128 && my >= by && my <= by+16) {
                    parent.toast("Delete: " + w.method_252()); return true;
                }
                y += CARD_H + CARD_GAP;
            }
        }
        return false;
    }

    private void openWorld(class_34 w) {
        if (w.method_27021()) { parent.toast("World is locked!"); return; }
        // IntegratedServerLoader.start(String worldName, Runnable onCancel)
        mc.method_41735().method_57784(w.method_248(), () -> mc.method_1507(this));
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double h, double v) {
        int listH  = field_22790 - (NAV_H + TOOLBAR_H + 8) - 8;
        int totalH = getFiltered().size() * (CARD_H + CARD_GAP);
        scrollOffset = (int) Math.max(0, Math.min(Math.max(0, totalH - listH), scrollOffset - v * 16));
        return true;
    }

    @Override
    public boolean method_25400(class_11905 input) {
        String s = input.method_74226();
        if (!s.isEmpty()) { searchQuery += s; scrollOffset = 0; }
        return true;
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.method_74228() == 259 && !searchQuery.isEmpty()) {
            searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
            scrollOffset = 0; return true;
        }
        return super.method_25404(input);
    }

    @Override public boolean method_25421() { return false; }

    private List<class_34> getFiltered() {
        String q = searchQuery.toLowerCase();
        List<class_34> out = new ArrayList<>();
        for (class_34 w : worlds) {
            boolean cat = switch (activeFilter) {
                case "survival" -> !w.method_257() && w.method_247() == class_1934.field_9215;
                case "creative" -> w.method_247() == class_1934.field_9220;
                case "hardcore" -> w.method_257();
                default         -> true;
            };
            boolean term = q.isEmpty()
                    || w.method_252().toLowerCase().contains(q)
                    || w.method_248().toLowerCase().contains(q);
            if (cat && term) out.add(w);
        }
        return out;
    }
}
