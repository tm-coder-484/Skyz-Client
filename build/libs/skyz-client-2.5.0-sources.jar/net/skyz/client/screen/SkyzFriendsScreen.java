package net.skyz.client.screen;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11905;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.skyz.client.util.*;

/**
 * Friends/Social screen.
 * If Essential mod is loaded, opens Essential's social UI via reflection.
 * Otherwise shows a friendly install prompt.
 */
public class SkyzFriendsScreen extends class_437 {

    private final SkyzTitleScreen parent;
    private final boolean hasEssential;
    private class_437 essentialScreen = null;
    private String statusMsg = "";

    public SkyzFriendsScreen(SkyzTitleScreen parent) {
        super(class_2561.method_43470("Friends"));
        this.parent = parent;
        this.hasEssential = FabricLoader.getInstance().isModLoaded("essential");
    }

    @Override
    protected void method_25426() {
        method_37063(SkyzButton.of(field_22789 - 82, 7, 74, 18, "\u2190 Back",
                () -> field_22787.method_1507(parent)));

        if (hasEssential) {
            tryOpenEssentialSocial();
        }
    }

    private void tryOpenEssentialSocial() {
        try {
            // Try Essential's FriendsScreen via reflection
            Class<?> cls = Class.forName("gg.essential.gui.friends.FriendsScreen");
            essentialScreen = (class_437) cls.getDeclaredConstructors()[0].newInstance();
            field_22787.method_1507(essentialScreen);
        } catch (Exception e1) {
            try {
                // Alternative: SocialMenuScreen
                Class<?> cls = Class.forName("gg.essential.gui.menu.SocialMenuScreen");
                essentialScreen = (class_437) cls.getDeclaredConstructors()[0].newInstance();
                field_22787.method_1507(essentialScreen);
            } catch (Exception e2) {
                statusMsg = "Essential loaded but social screen not found (v" +
                        FabricLoader.getInstance().getModContainer("essential")
                                .map(m -> m.getMetadata().getVersion().getFriendlyString())
                                .orElse("?") + ")";
            }
        }
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Background
        SkyzRenderHelper.fillGradientV(ctx, 0, 0, field_22789, field_22790/2, SkyzTheme.BG1, SkyzTheme.BG2);
        SkyzRenderHelper.fillGradientV(ctx, 0, field_22790/2, field_22789, field_22790/2, SkyzTheme.BG2, SkyzTheme.BG3);
        ctx.method_25294(0, 0, field_22789, 28, 0x88000000);
        ctx.method_25294(0, 27, field_22789, 28, 0x558CD2FF);
        ctx.method_25300(field_22793, "\uD83D\uDC65  Friends", field_22789/2, 10, SkyzColors.TEXT_PRIMARY);

        int cy = field_22790/2 - 40;

        if (!hasEssential) {
            // No Essential installed
            ctx.method_25294(field_22789/2-120, cy-8, field_22789/2+120, cy+90, 0x88000000);
            ctx.method_25294(field_22789/2-120, cy-8, field_22789/2+120, cy-7, 0x558CD2FF);
            ctx.method_25300(field_22793,
                    "\uD83D\uDC65 Friends requires Essential mod", field_22789/2, cy+4, 0xFFFFBB44);
            ctx.method_25300(field_22793,
                    "Essential adds friends, cosmetics and servers.", field_22789/2, cy+20, SkyzColors.TEXT_MUTED);
            ctx.method_25300(field_22793,
                    "Install it from essential.gg or CurseForge.", field_22789/2, cy+34, SkyzColors.TEXT_MUTED);
            // Install button drawn by addDrawableChild below - done in init() but we add it here conditionally
            ctx.method_25300(field_22793,
                    "essential.gg", field_22789/2, cy+60, 0xFF4CFA87);
        } else if (!statusMsg.isEmpty()) {
            // Essential loaded but couldn't open UI
            ctx.method_25300(field_22793, "\u26A0 " + statusMsg,
                    field_22789/2, cy + 10, 0xFFFFBB44);
            ctx.method_25300(field_22793,
                    "Try opening Essential directly from your mods.", field_22789/2, cy+26, SkyzColors.TEXT_MUTED);
        }

        super.method_25394(ctx, mouseX, mouseY, delta);
        parent.toast.render(ctx, field_22789, delta);
    }

    @Override public boolean method_25400(class_11905 input) { return false; }
}
