package net.skyz.client.screen;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.skyz.client.util.*;
import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Shaders screen integrating with Iris.
 *
 * - Scans .minecraft/shaderpacks/ for real installed shader packs
 * - If Iris is present: "Open Iris Shaders" button opens ShaderPackScreen via reflection
 *   (Iris has no stable public API for screen opening; we use reflection as recommended
 *    by community practice)
 * - Shows enable/disable toggle via IrisApi.v0 if available
 * - Falls back to a styled list with instructions if Iris isn't installed
 */
public class SkyzShadersScreen extends class_437 {

    private final SkyzTitleScreen parent;

    private static final boolean HAS_IRIS =
            FabricLoader.getInstance().isModLoaded("iris");

    // Real shader packs found on disk
    private final List<ShaderPack> packs = new ArrayList<>();
    private int selectedPack = 0;
    private int scrollOffset = 0;

    record ShaderPack(String name, String fileName, boolean isEnabled) {}

    private static final int NAV_H  = 30;
    private static final int PAD    = 12;
    private static final int LIST_W = 260;
    private static final int ROW_H  = 48;

    public SkyzShadersScreen(SkyzTitleScreen parent) {
        super(class_2561.method_43470("Shaders"));
        this.parent = parent;
        // loadShaderPacks() called in init() on the render thread
    }

    private void loadShaderPacks() {
        packs.clear();
        // Get the active shaderpack name from Iris if possible
        String activeName = getActiveShaderpackName();

        // Scan shaderpacks folder
        File shaderpacksDir = new File(net.minecraft.class_310.method_1551()
                .field_1697, "shaderpacks");
        if (shaderpacksDir.exists() && shaderpacksDir.isDirectory()) {
            File[] files = shaderpacksDir.listFiles();
            if (files != null) {
                for (File f : files) {
                    String n = f.getName();
                    if (n.endsWith(".zip") || n.endsWith(".txt") || f.isDirectory()) {
                        String displayName = n.replace(".zip", "").replace(".txt", "");
                        boolean active = displayName.equals(activeName) || n.equals(activeName);
                        packs.add(new ShaderPack(displayName, n, active));
                    }
                }
            }
        }

        // Always add "Off (Vanilla)" at the top
        boolean noneActive = activeName == null || activeName.isEmpty() || activeName.equals("(off)");
        packs.add(0, new ShaderPack("No Shaders (Vanilla)", "(off)", noneActive));
    }

    /** Get the currently loaded shaderpack name from Iris via reflection. */
    private String getActiveShaderpackName() {
        if (!HAS_IRIS) return null;
        try {
            Class<?> irisClass = Class.forName("net.irisshaders.iris.Iris");
            Method   getConfig = irisClass.getMethod("getIrisConfig");
            Object   config    = getConfig.invoke(null);
            Method   getName   = config.getClass().getMethod("getShaderPackName");
            Object   result    = getName.invoke(config);
            return result != null ? result.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** Open Iris ShaderPackScreen via reflection. */
    private boolean openIrisShaderScreen() {
        if (!HAS_IRIS) return false;
        try {
            Class<?> screenClass = Class.forName("net.irisshaders.iris.gui.screen.ShaderPackScreen");
            java.lang.reflect.Constructor<?> ctor = screenClass.getConstructor(class_437.class);
            class_437 shaderScreen = (class_437) ctor.newInstance(this);
            net.minecraft.class_310.method_1551().method_1507(shaderScreen);
            return true;
        } catch (Exception e) {
            net.skyz.client.SkyzClientMod.LOGGER.warn("[Skyz Client] Could not open Iris screen: {}", e.getMessage());
            return false;
        }
    }

    /** Apply a shader pack by name via Iris API reflection. */
    private void applyShaderPack(String packName) {
        if (!HAS_IRIS) { parent.toast("Install Iris Shaders to use shader packs!"); return; }
        try {
            Class<?> irisClass = Class.forName("net.irisshaders.iris.Iris");
            Method   getConfig = irisClass.getMethod("getIrisConfig");
            Object   config    = getConfig.invoke(null);

            if (packName.equals("(off)")) {
                Method setShadersEnabled = null;
                try {
                    Class<?> apiClass = Class.forName("net.irisshaders.iris.apiimpl.IrisApiV0ConfigImpl");
                    setShadersEnabled = apiClass.getMethod("setShadersEnabledAndApply", boolean.class);
                    Object apiInst = irisClass.getField("irisConfig").get(null);
                    setShadersEnabled.invoke(config, false);
                } catch (Exception ignored) {}
            } else {
                Method setShaderPackName = config.getClass().getMethod("setShaderPackName", String.class);
                setShaderPackName.invoke(config, packName);
                Method save = config.getClass().getMethod("save");
                save.invoke(config);
                // Reload
                Method reload = irisClass.getMethod("reload");
                reload.invoke(null);
            }
            loadShaderPacks(); // refresh list
            parent.toast("Applied: " + (packName.equals("(off)") ? "No Shaders" : packName));
        } catch (Exception e) {
            parent.toast("Could not apply shader: " + e.getMessage());
            // Fall back to opening the full Iris screen
            openIrisShaderScreen();
        }
    }

    private boolean loading = true;

    @Override
    protected void method_25426() {
        method_37063(SkyzButton.of(field_22789 - 82, 7, 74, 18, "\u2190 Back",
                () -> field_22787.method_1507(parent)));

        if (HAS_IRIS) {
            method_37063(SkyzButton.of(PAD, NAV_H + 4, 180, 18,
                    "\uD83C\uDF05 Open Full Iris Shaders Screen",
                    () -> {
                        if (!openIrisShaderScreen())
                            parent.toast("Could not open Iris screen.");
                    }));
        }

        method_37063(SkyzButton.of(HAS_IRIS ? PAD + 188 : PAD, NAV_H + 4, 70, 18,
                "\u21BB Refresh",
                () -> {
                    loading = true;
                    java.util.concurrent.CompletableFuture.runAsync(this::loadShaderPacks)
                        .thenRun(() -> { loading = false; parent.toast("Refreshed!"); });
                }));

        // Load shader packs asynchronously so we don't freeze the render thread
        loading = true;
        java.util.concurrent.CompletableFuture.runAsync(this::loadShaderPacks)
            .thenRun(() -> loading = false);
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        SkyzRenderHelper.fillGradientV(ctx, 0, 0, field_22789, field_22790, SkyzTheme.BG1, SkyzTheme.BG2);
        drawNavBar(ctx);
        if (loading) {
            ctx.method_25300(field_22793, "Loading shader packs...",
                    field_22789/2, field_22790/2, SkyzColors.TEXT_MUTED);
        } else {
            drawShaderList(ctx, mouseX, mouseY);
            drawInfoPanel(ctx, mouseX, mouseY);
        }
        super.method_25394(ctx, mouseX, mouseY, delta);
        parent.toast.render(ctx, field_22789, delta);
    }

    private void drawNavBar(class_332 ctx) {
        ctx.method_25303(field_22793, "SKYZ", 10, 10, 0xFFF0F8FF);
        int x = 10 + field_22793.method_1727("SKYZ") + 6;
        ctx.method_25303(field_22793, "/", x, 10, 0x4D8CD2FF);
        x += field_22793.method_1727("/") + 6;
        ctx.method_25303(field_22793, "SHADERS", x, 10, 0x888CD2FF);

        // Iris status badge
        String badge = HAS_IRIS
                ? "\uD83C\uDF05 Iris Active"
                : "\u26A0 Iris not installed";
        int badgeCol = HAS_IRIS ? 0x668CD2FF : 0x99FF9944;
        ctx.method_25303(field_22793, badge,
                field_22789 - PAD - field_22793.method_1727(badge), 10, badgeCol);

        SkyzRenderHelper.drawDivider(ctx, 0, NAV_H, field_22789);
    }

    private void drawShaderList(class_332 ctx, int mx, int my) {
        int x = PAD, y = NAV_H + 30, w = LIST_W, h = field_22790 - NAV_H - 30;
        SkyzRenderHelper.fillPanel(ctx, x, y, w, h, 0x44081830, 0x228CD2FF);

        ctx.method_25303(field_22793, "Shader Packs (" + (packs.size() - 1) + " found)",
                x + 10, y + 10, SkyzColors.TEXT_PRIMARY);
        if (!HAS_IRIS) {
            ctx.method_25303(field_22793, "Install Iris to enable", x + 10, y + 22, 0x99FF9944);
        }
        SkyzRenderHelper.fillRect(ctx, x + 1, y + (HAS_IRIS ? 24 : 34), w - 2, 1, 0x228CD2FF);

        int rowY  = y + (HAS_IRIS ? 30 : 40) - scrollOffset;
        int listH = h - (HAS_IRIS ? 30 : 40) - 10;
        ctx.method_44379(x, y + (HAS_IRIS ? 30 : 40), x + w, y + h - 10);

        for (int i = 0; i < packs.size(); i++) {
            ShaderPack p    = packs.get(i);
            boolean    sel  = i == selectedPack;
            boolean    hov  = mx >= x + 1 && mx <= x + w - 1 && my >= rowY && my <= rowY + ROW_H;

            if (sel)       SkyzRenderHelper.fillRect(ctx, x + 1, rowY, w - 2, ROW_H, 0x44143C6E);
            else if (hov)  SkyzRenderHelper.fillRect(ctx, x + 1, rowY, w - 2, ROW_H, 0x22143C6E);

            // Active indicator
            if (p.isEnabled())
                SkyzRenderHelper.fillRect(ctx, x + 1, rowY, 3, ROW_H, 0xCC8CD2FF);

            String icon = p.fileName().equals("(off)") ? "\uD83D\uDFEB" : "\uD83C\uDF05";
            ctx.method_25303(field_22793, icon, x + 10, rowY + 10, 0xFFFFFFFF);

            String name = p.name();
            while (field_22793.method_1727(name) > w - 50 && name.length() > 3)
                name = name.substring(0, name.length() - 3) + "...";
            ctx.method_25303(field_22793, name, x + 28, rowY + 8,
                    p.isEnabled() ? 0xFF8CD2FF : SkyzColors.TEXT_PRIMARY);
            ctx.method_25303(field_22793, p.isEnabled() ? "\u2726 Active" : p.fileName(),
                    x + 28, rowY + 22, p.isEnabled() ? 0x558CD2FF : 0x338CD2FF);

            // Apply button on hover / selected
            if (hov || sel) {
                int bx = x + w - 52, by = rowY + ROW_H / 2 - 8;
                boolean bHov = mx >= bx && mx <= bx + 46 && my >= by && my <= by + 16;
                SkyzRenderHelper.fillPanel(ctx, bx, by, 46, 16,
                        bHov ? 0x661E6EC8 : 0x441864A0, 0x558CD2FF);
                ctx.method_25300(field_22793,
                        p.isEnabled() ? "Active" : "Apply",
                        bx + 23, by + 4,
                        p.isEnabled() ? 0x8890D2FF : (bHov ? 0xFFFFFFFF : 0xCCDDFFFF));
            }

            rowY += ROW_H;
        }
        ctx.method_44380();

        // Shaderpack folder hint at bottom
        ctx.method_25303(field_22793, "Drop .zip into shaderpacks/ folder",
                x + 8, y + h - 16, 0x338CD2FF);
    }

    private void drawInfoPanel(class_332 ctx, int mx, int my) {
        int x = PAD + LIST_W + 10;
        int y = NAV_H + 30;
        int w = field_22789 - x - PAD;
        int h = field_22790 - NAV_H - 30;

        SkyzRenderHelper.fillPanel(ctx, x, y, w, h, 0x44081830, 0x228CD2FF);

        ShaderPack sel = packs.isEmpty() ? null : packs.get(selectedPack);
        ctx.method_25303(field_22793, "Pack Info", x + 10, y + 10, SkyzColors.TEXT_PRIMARY);
        SkyzRenderHelper.fillRect(ctx, x + 1, y + 24, w - 2, 1, 0x228CD2FF);

        int iy = y + 32;
        if (sel != null) {
            ctx.method_25303(field_22793, sel.name(), x + 10, iy, 0xFF8CD2FF); iy += 14;
            ctx.method_25303(field_22793, "File: " + sel.fileName(), x + 10, iy, 0x4D8CD2FF); iy += 14;
            ctx.method_25303(field_22793, "Status: " + (sel.isEnabled() ? "\u2726 Active" : "Inactive"),
                    x + 10, iy, sel.isEnabled() ? 0x8890D2FF : SkyzColors.TEXT_MUTED); iy += 22;
        }

        if (!HAS_IRIS) {
            iy += 10;
            SkyzRenderHelper.fillPanel(ctx, x + 10, iy, w - 20, 60, 0x33FF9900, 0x55FF9900);
            ctx.method_25303(field_22793, "\u26A0 Iris Shaders not installed", x + 16, iy + 8, 0xFFFF9944);
            ctx.method_25303(field_22793, "To use shader packs, install:", x + 16, iy + 20, SkyzColors.TEXT_MUTED);
            ctx.method_25303(field_22793, "Iris + Sodium from modrinth.com", x + 16, iy + 32, 0x668CD2FF);
            ctx.method_25303(field_22793, "modrinth.com/mod/iris", x + 16, iy + 44, 0x558CD2FF);
        } else {
            iy += 10;
            ctx.method_25303(field_22793, "Shaderpacks folder:", x + 10, iy, SkyzColors.TEXT_MUTED); iy += 12;
            String path = new File(net.minecraft.class_310.method_1551().field_1697, "shaderpacks").getAbsolutePath();
            while (field_22793.method_1727(path) > w - 20 && path.length() > 10)
                path = "..." + path.substring(Math.min(path.length(), path.length() - (w - 20) / 5));
            ctx.method_25303(field_22793, path, x + 10, iy, 0x338CD2FF); iy += 22;

            ctx.method_25303(field_22793, "Quick tips:", x + 10, iy, SkyzColors.TEXT_MUTED); iy += 14;
            ctx.method_25303(field_22793, "\u00B7 Drop .zip files into shaderpacks/", x + 16, iy, 0x558CD2FF); iy += 12;
            ctx.method_25303(field_22793, "\u00B7 Use 'Refresh' to reload the list", x + 16, iy, 0x558CD2FF); iy += 12;
            ctx.method_25303(field_22793, "\u00B7 'Open Full Iris Screen' for", x + 16, iy, 0x558CD2FF); iy += 12;
            ctx.method_25303(field_22793, "   full shader settings", x + 16, iy, 0x558CD2FF);
        }
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (super.method_25402(click, doubled)) return true;
        double mx = click.comp_4798(), my = click.comp_4799();

        int lx = PAD, ly = NAV_H + 30 + (HAS_IRIS ? 30 : 40);
        int rowY = ly - scrollOffset;
        for (int i = 0; i < packs.size(); i++) {
            ShaderPack p = packs.get(i);
            if (my >= rowY && my <= rowY + ROW_H && mx >= lx && mx <= lx + LIST_W) {
                selectedPack = i;
                // Check if Apply button clicked
                int bx = lx + LIST_W - 52, by = rowY + ROW_H / 2 - 8;
                if (mx >= bx && mx <= bx + 46 && my >= by && my <= by + 16 && !p.isEnabled()) {
                    applyShaderPack(p.fileName());
                }
                return true;
            }
            rowY += ROW_H;
        }
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double h, double v) {
        int listH  = field_22790 - NAV_H - 30 - (HAS_IRIS ? 30 : 40) - 10;
        int totalH = packs.size() * ROW_H;
        scrollOffset = (int) Math.max(0, Math.min(Math.max(0, totalH - listH), scrollOffset - v * 16));
        return true;
    }

    @Override public boolean method_25421() { return false; }
}
