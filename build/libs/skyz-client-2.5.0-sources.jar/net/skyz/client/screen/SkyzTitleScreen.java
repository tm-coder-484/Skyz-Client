package net.skyz.client.screen;

import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.skyz.client.util.*;
import java.nio.file.Path;
import java.util.Calendar;
import java.util.List;

/**
 * Main Skyz Client title screen - v2.5.0 for Minecraft 1.21.11.
 *
 * Fixed in this version:
 *  - Button layout: calculated from screen centre so nothing clips
 *  - All navigation targets now have real custom screens
 *  - Music via MC SoundManager (MUSIC_MENU)
 *  - Drag-and-drop background via SkyzBackgroundManager
 *  - Mod integrations detected at runtime
 */
public class SkyzTitleScreen extends class_437 {

    // Shared utilities (package-visible for sub-screens)
    final ParticleSystem particles = new ParticleSystem();
    final Toast          toast     = new Toast();
    /** Set by TitleScreenMixin when player disconnects from a server. */
    public boolean pendingOpenMultiplayer = false;
    private float        tick      = 0f;
    private boolean      musicMuted = false;

    private static final String[] SPLASHES = {
        "Look up. Fly higher.",
        "Now running on 1.21.11 \u2726",
        "Sodium-powered frames \u2726",
        "Touch the clouds",
        "Open skies ahead",
        "v2.5.0 \u2014 sharper than ever \u2726",
        "Iris shaders: activated \u2726",
        "Essential by EssentialGG \u2726",
        "Drag a PNG/JPG to set your background!",
    };
    private final String splash;

    // Button geometry - calculated dynamically in init()
    private static final int BTN_W   = 200;
    private static final int BTN_H   = 20;
    private static final int BTN_GAP = 3;

    public SkyzTitleScreen() {
        super(class_2561.method_43470("Skyz Client"));
        splash = SPLASHES[(int)(Math.random() * SPLASHES.length)];
    }

    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    // Init
    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    @Override
    protected void method_25426() {
        particles.resize(field_22789, field_22790);
        SkyzBackgroundManager.getInstance().tryLoadSaved();
        if (!musicMuted) SkyzAudioManager.getInstance().play();

        int cx = field_22789 / 2;

        // 8 rows (some are half pairs, all same height) + 1 extra spacer before quit
        int numRows = 8;
        int totalH  = numRows * BTN_H + (numRows - 1) * BTN_GAP + 4; // +4 spacer before quit

        // Logo bottom: never push buttons off screen
        int logoBottom = Math.min((int)(field_22790 * 0.40f), field_22790 - totalH - 16);
        int startY     = logoBottom + 8; // tight gap after logo
        int y          = startY;
        int h          = BTN_W / 2 - BTN_GAP / 2;

        row(cx, y, BTN_W, "\uD83C\uDF0D  Singleplayer",
                () -> field_22787.method_1507(new SkyzSingleplayerScreen(this)));
        y += BTN_H + BTN_GAP;

        row(cx, y, BTN_W, "\u25C8  Multiplayer",
                () -> field_22787.method_1507(new SkyzMultiplayerScreen(this)));
        y += BTN_H + BTN_GAP;

        row(cx, y, BTN_W, "\uD83E\uDDE9  Mods",
                () -> field_22787.method_1507(new SkyzModsScreen(this)));
        y += BTN_H + BTN_GAP;

        // Row: Options | Skyz Settings
        half(cx, y, "\u2699  Options",
                () -> field_22787.method_1507(new class_429(this, field_22787.field_1690)));
        half(cx + h + BTN_GAP, y, "\u2726  Skyz Settings",
                () -> field_22787.method_1507(new SkyzSettingsScreen(this)));
        y += BTN_H + BTN_GAP;

        // Row: Skin Editor | Cosmetics
        half(cx, y, "\uD83E\uDDCD  Skin Editor",
                () -> toast("Skin Editor \u2014 coming soon!"));
        half(cx + h + BTN_GAP, y, "\u2728  Cosmetics",
                () -> toast("Install Essential: modrinth.com/mod/essential"));
        y += BTN_H + BTN_GAP;

        // Row: Shaders | HUD Editor
        half(cx, y, "\uD83C\uDF05  Shaders",
                () -> field_22787.method_1507(new SkyzShadersScreen(this)));
        half(cx + h + BTN_GAP, y, "\uD83C\uDF9B  HUD Editor",
                () -> field_22787.method_1507(new SkyzHudEditorScreen(this)));
        y += BTN_H + BTN_GAP;

        row(cx, y, BTN_W, "\uD83D\uDC65  Friends",
                () -> field_22787.method_1507(new SkyzFriendsScreen(this)));
        y += BTN_H + BTN_GAP + 4; // small spacer before quit

        method_37063(SkyzButton.danger(
                cx - BTN_W / 2, y, BTN_W, BTN_H,
                "\u2297  Quit Game",
                () -> field_22787.method_1592()));

        // Re-open multiplayer screen after server disconnect
        if (pendingOpenMultiplayer) {
            pendingOpenMultiplayer = false;
            field_22787.method_1507(new SkyzMultiplayerScreen(this));
        }
    }

    private void row(int cx, int y, int w, String label, Runnable action) {
        method_37063(SkyzButton.of(cx - w / 2, y, w, BTN_H, label, action));
    }

    private void half(int x, int y, String label, Runnable action) {
        int w = BTN_W / 2 - BTN_GAP / 2;
        method_37063(SkyzButton.of(x - BTN_W / 2, y, w, BTN_H, label, action));
    }

    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    // Render
    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        tick += delta;

        SkyzBackgroundManager bg = SkyzBackgroundManager.getInstance();
        if (bg.hasBackground()) {
            bg.draw(ctx, field_22789, field_22790);
            bg.drawDim(ctx, field_22789, field_22790);
        } else {
            drawGradientBackground(ctx);
        }

        particles.tick(ctx, delta);
        drawLogo(ctx);

        super.method_25394(ctx, mouseX, mouseY, delta); // draws buttons

        drawHudClock(ctx);
        drawSplash(ctx);
        drawMuteButton(ctx, mouseX, mouseY);
        drawBgHint(ctx);

        if (bg.isDragging()) drawDropZoneOverlay(ctx);

        toast.render(ctx, field_22789, delta);
    }

    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    // Background
    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    private void drawGradientBackground(class_332 ctx) {
        SkyzRenderHelper.fillGradientV(ctx, 0, 0,          field_22789, field_22790 / 3, SkyzTheme.BG1, SkyzTheme.BG2);
        SkyzRenderHelper.fillGradientV(ctx, 0, field_22790/3,   field_22789, field_22790 / 3, SkyzTheme.BG2, SkyzTheme.BG3);
        SkyzRenderHelper.fillGradientV(ctx, 0, field_22790*2/3, field_22789, field_22790 / 3, SkyzTheme.BG3, SkyzTheme.BG1);
        // Radial glow
        int gcx = field_22789 / 2, gcy = field_22790 / 3, gr = Math.min(field_22789, field_22790) / 2;
        for (int ring = gr; ring > 0; ring -= 10) {
            int a = (int)(10 * (1f - (float)ring/gr));
            if (a <= 0) continue;
            for (int dy = -ring; dy <= ring; dy += 5) {
                double hw = Math.sqrt(Math.max(0, (double)ring*ring - (double)dy*dy));
                ctx.method_25294((int)(gcx-hw), gcy+dy, (int)(gcx+hw), gcy+dy+5, (a<<24)|0x46A0FF);
            }
        }
        SkyzRenderHelper.fillGradientV(ctx, 0, field_22790*3/4, field_22789, field_22790/4, 0x00051432, 0x8C051432);
    }

    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    // Logo
    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    private void drawLogo(class_332 ctx) {
        int cx     = field_22789 / 2;
        int scale  = 4;
        int logoY  = (int)(field_22790 * 0.12f);
        String logo    = "SKYZ";
        String tagline = "Client  \u00B7  Java Edition  \u00B7  1.21.11";
        int logoW = field_22793.method_1727(logo) * scale;

        ctx.method_51448().pushMatrix();
        ctx.method_51448().scale(scale, scale);
        ctx.method_51433(field_22793, logo, (cx - logoW/2)/scale, (logoY+2)/scale, 0x4064A8FF, false);
        ctx.method_51433(field_22793, logo, (cx - logoW/2)/scale, logoY/scale,     0xFFF0F8FF, false);
        ctx.method_51448().popMatrix();

        int taglineY = logoY + scale*9 + 8;
        ctx.method_25300(field_22793, tagline, cx, taglineY, 0x8BB4E6FF);

        int lineY = taglineY + 14;
        SkyzRenderHelper.fillGradientH(ctx, cx-110, lineY, 110, 1, 0x00A0D4FF, 0xA0A0D4FF);
        SkyzRenderHelper.fillGradientH(ctx, cx,     lineY, 110, 1, 0xA0A0D4FF, 0x00A0D4FF);

        float pulse    = (float)(Math.sin(tick * 0.05) * 0.3 + 0.7);
        int   dotAlpha = (int)(pulse * 200);
        SkyzRenderHelper.fillRect(ctx, cx-2, lineY-2, 4, 4, (dotAlpha<<24)|0x8CD2FF);
        SkyzRenderHelper.fillRect(ctx, cx-1, lineY-1, 2, 2, 0xE68CD2FF);
    }

    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    // HUD overlays
    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    private void drawHudClock(class_332 ctx) {
        Calendar now = Calendar.getInstance();
        String hud = String.format("Skyz Client  \u00B7  v2.5.0  \u00B7  %02d:%02d",
                now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE));
        ctx.method_25300(field_22793, hud, field_22789/2, field_22790-12, 0x4D8CD2FF);
    }

    private void drawSplash(class_332 ctx) {
        ctx.method_25303(field_22793, splash,
                field_22789 - field_22793.method_1727(splash) - 6, 6, 0x618CC8FF);
    }

    private void drawMuteButton(class_332 ctx, int mx, int my) {
        String icon = musicMuted ? "\uD83D\uDD07 Music OFF" : "\uD83D\uDD0A Music ON";
        int bw = field_22793.method_1727(icon) + 14, bh = 14;
        int bx = field_22789 - bw - 6, by = field_22790 - bh - 16;
        boolean hov = mx>=bx && mx<=bx+bw && my>=by && my<=by+bh;
        SkyzRenderHelper.fillPanel(ctx, bx, by, bw, bh,
                hov ? 0x44143C6E : 0x22091E46, hov ? 0x558CD2FF : 0x228CD2FF);
        ctx.method_25303(field_22793, icon, bx+7, by+3,
                musicMuted ? 0x558CD2FF : SkyzColors.TEXT_MUTED);
    }

    private void drawBgHint(class_332 ctx) {
        SkyzBackgroundManager bg = SkyzBackgroundManager.getInstance();
        String hint = bg.hasBackground()
                ? "\uD83D\uDDBC Drag image to change BG  |  [X] Clear"
                : "\uD83D\uDDBC Drag PNG/JPG here to set background";
        ctx.method_25303(field_22793, hint, 6, field_22790-12, 0x2E8CD2FF);
    }

    private void drawDropZoneOverlay(class_332 ctx) {
        ctx.method_25294(0, 0, field_22789, field_22790, 0xCC050F2A);
        int p = 20, col = 0xCC8CD2FF;
        SkyzRenderHelper.fillRect(ctx, p,       p,       field_22789-p*2, 2,    col);
        SkyzRenderHelper.fillRect(ctx, p,       field_22790-p-2, field_22789-p*2, 2, col);
        SkyzRenderHelper.fillRect(ctx, p,       p,       2, field_22790-p*2,   col);
        SkyzRenderHelper.fillRect(ctx, field_22789-p-2, p,     2, field_22790-p*2,   col);
        ctx.method_25300(field_22793, "Drop your image here",           field_22789/2, field_22790/2-12, 0xFFFFFFFF);
        ctx.method_25300(field_22793, "PNG, JPG or BMP \u2014 any size",field_22789/2, field_22790/2+4,  0x888CD2FF);
    }

    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    // Input
    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    @Override
    public void method_29638(List<Path> paths) {
        SkyzBackgroundManager bg = SkyzBackgroundManager.getInstance();
        bg.setDragging(false);
        if (!bg.onFileDrop(paths)) toast("Not an image. Use PNG, JPG or BMP.");
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (super.method_25402(click, doubled)) return true;
        double mx = click.comp_4798(), my = click.comp_4799();

        // Mute toggle
        String icon = musicMuted ? "\uD83D\uDD07 Music OFF" : "\uD83D\uDD0A Music ON";
        int bw = field_22793.method_1727(icon)+14, bh = 14;
        int bx = field_22789-bw-6, by = field_22790-bh-16;
        if (mx>=bx && mx<=bx+bw && my>=by && my<=by+bh) {
            musicMuted = !SkyzAudioManager.getInstance().toggle();
            toast(musicMuted ? "Music muted" : "Music playing");
            return true;
        }

        // Clear BG hint
        SkyzBackgroundManager bg = SkyzBackgroundManager.getInstance();
        if (bg.hasBackground()) {
            int hx = 6 + field_22793.method_1727("\uD83D\uDDBC Drag image to change BG  |  ");
            int hy = field_22790 - 12;
            if (mx>=hx && mx<=hx+field_22793.method_1727("[X] Clear") && my>=hy-1 && my<=hy+9) {
                bg.clear(); toast("Background cleared"); return true;
            }
        }
        return false;
    }

    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    // Lifecycle
    // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    public void toast(String msg) { toast.show(msg); }

    @Override public boolean method_25421() { return false; }

    @Override
    public void method_25410(int width, int height) {
        super.method_25410(width, height);
        particles.resize(width, height);
    }

    @Override
    public void method_25432() {
        SkyzAudioManager.getInstance().stop();
    }
}
