package net.skyz.client.screen;

import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_12239;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_412;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_641;
import net.minecraft.class_642;
import net.minecraft.class_644;
import net.skyz.client.util.*;
import java.util.*;

public class SkyzMultiplayerScreen extends class_437 {

    private final SkyzTitleScreen            parent;
    private final class_310            mc;
    private final class_641                 serverList;
    private final class_644 pinger;

    private String  searchQuery      = "";
    private String  activeFilter     = "all";
    private int     scrollOffset     = 0;
    private boolean connectingDirect = false;
    private String  directAddr       = "";

    private static final int NAV_H     = 30;
    private static final int TOOLBAR_H = 28;
    private static final int CARD_H    = 64;
    private static final int CARD_GAP  = 6;
    private static final int PAD       = 12;

    public SkyzMultiplayerScreen(SkyzTitleScreen parent) {
        super(class_2561.method_43470("Multiplayer"));
        this.parent     = parent;
        this.mc         = class_310.method_1551();
        this.serverList = new class_641(mc);
        this.serverList.method_2981();
        this.pinger     = new class_644();
    }

    @Override
    protected void method_25426() {
        method_37063(SkyzButton.of(field_22789 - 82, 7, 74, 18, "\u2190 Back",
                () -> {
                    pinger.method_3004();
                    field_22787.method_1507(parent);
                }));
        method_37063(SkyzButton.of(PAD, NAV_H + 4, 100, 20, "+ Add Server",
                () -> field_22787.method_1507(new net.minecraft.class_500(this))));
        method_37063(SkyzButton.of(PAD + 108, NAV_H + 4, 120, 20, "\u26A1 Direct Connect",
                () -> { connectingDirect = true; directAddr = ""; }));

        // Ping all servers asynchronously
        pingServers();
    }

    private void pingServers() {
        for (int i = 0; i < serverList.method_2984(); i++) {
            class_642 info = serverList.method_2982(i);
            try {
                class_639 addr = class_639.method_2950(info.field_3761);
                pinger.method_3003(info, () -> serverList.method_2987(), () -> {}, class_12239.method_75867(false));
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void method_25393() {
        super.method_25393();
        try { pinger.method_3000(); } catch (Exception ignored) {}
    }

    @Override
    public void method_25432() {
        pinger.method_3004();
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        SkyzRenderHelper.fillGradientV(ctx, 0, 0, field_22789, field_22790, SkyzTheme.BG1, SkyzTheme.BG2);
        drawNavBar(ctx);
        drawToolbar(ctx, mouseX, mouseY);
        drawServerList(ctx, mouseX, mouseY);
        if (connectingDirect) drawDirectConnectOverlay(ctx, mouseX, mouseY);
        super.method_25394(ctx, mouseX, mouseY, delta);
        parent.toast.render(ctx, field_22789, delta);
    }

    private void drawNavBar(class_332 ctx) {
        ctx.method_25303(field_22793, "SKYZ", 10, 10, 0xFFF0F8FF);
        int x = 10 + field_22793.method_1727("SKYZ") + 6;
        ctx.method_25303(field_22793, "/", x, 10, 0x4D8CD2FF);
        x += field_22793.method_1727("/") + 6;
        ctx.method_25303(field_22793, "MULTIPLAYER", x, 10, 0x888CD2FF);
        SkyzRenderHelper.drawDivider(ctx, 0, NAV_H, field_22789);
    }

    private void drawToolbar(class_332 ctx, int mx, int my) {
        int ty = NAV_H + 4;
        int sX = PAD + 238, sW = Math.min(200, field_22789 - sX - PAD - 80);
        SkyzRenderHelper.fillPanel(ctx, sX, ty, sW, 20, 0x55091E46, 0x338CD2FF);
        String q = searchQuery.isEmpty() ? "Search servers..." : searchQuery;
        ctx.method_25303(field_22793, q, sX + 6, ty + 6,
                searchQuery.isEmpty() ? 0x388CD2FF : SkyzColors.TEXT_PRIMARY);

        int fx = sX + sW + 8;
        for (String[] f : new String[][]{{"all","All"},{"fav","Favourites"}}) {
            boolean active = activeFilter.equals(f[0]);
            int fw = field_22793.method_1727(f[1]) + 14;
            SkyzRenderHelper.fillPanel(ctx, fx, ty, fw, 20,
                    active ? 0x553C6E90 : 0x33091E46, active ? 0x998CD2FF : 0x338CD2FF);
            ctx.method_25303(field_22793, f[1], fx + 7, ty + 6,
                    active ? 0xFFFFFFFF : SkyzColors.TEXT_MUTED);
            fx += fw + 4;
        }

        List<class_642> vis = getFiltered();
        String cnt = vis.size() + " server" + (vis.size() == 1 ? "" : "s");
        ctx.method_25303(field_22793, cnt,
                field_22789 - PAD - field_22793.method_1727(cnt), ty + 6, 0x4D8CD2FF);
    }

    private void drawServerList(class_332 ctx, int mx, int my) {
        List<class_642> servers = getFiltered();
        int listTop = NAV_H + TOOLBAR_H + 8;
        int listH   = field_22790 - listTop - 8;
        int cardW   = field_22789 - PAD * 2;
        int y       = listTop - scrollOffset;

        if (servers.isEmpty()) {
            ctx.method_25300(field_22793,
                    "No servers saved. Click \u201C+ Add Server\u201D or Direct Connect.",
                    field_22789 / 2, listTop + listH / 2, SkyzColors.TEXT_MUTED);
            return;
        }

        ctx.method_44379(0, listTop, field_22789, field_22790 - 8);
        for (class_642 s : servers) {
            if (y + CARD_H >= listTop && y <= listTop + listH)
                drawCard(ctx, s, PAD, y, cardW, CARD_H, mx, my);
            y += CARD_H + CARD_GAP;
        }
        ctx.method_44380();

        int totalH = servers.size() * (CARD_H + CARD_GAP);
        if (totalH > listH) {
            SkyzRenderHelper.fillRect(ctx, field_22789 - 4, listTop, 3, listH, 0x1A8CD2FF);
            int th  = Math.max(20, (int)((float) listH / totalH * listH));
            int ty2 = listTop + (int)((float) scrollOffset / Math.max(1, totalH - listH) * (listH - th));
            SkyzRenderHelper.fillRect(ctx, field_22789 - 4, ty2, 3, th, 0x558CD2FF);
        }
    }

    private void drawCard(class_332 ctx, class_642 s,
                          int x, int y, int w, int h, int mx, int my) {
        boolean hov = mx >= x && mx <= x + w && my >= y && my <= y + h;
        SkyzRenderHelper.fillPanel(ctx, x, y, w, h,
                hov ? 0x800C2A5A : SkyzColors.CARD_BG, hov ? 0x478CD2FF : SkyzColors.CARD_BORDER);

        ctx.method_25303(field_22793, "\uD83D\uDDA5", x + 12, y + (h - 8) / 2, 0xFFFFFFFF);

        int tx = x + 30;
        String name = (s.field_3752 != null && !s.field_3752.isEmpty()) ? s.field_3752 : s.field_3761;
        ctx.method_25303(field_22793, name, tx, y + 8, SkyzColors.TEXT_PRIMARY);
        ctx.method_25303(field_22793, s.field_3761, tx, y + 20, 0x4D8CD2FF);

        if (s.field_3757 != null && !s.field_3757.getString().isEmpty()) {
            String motd = s.field_3757.getString();
            int maxW = w - 165;
            while (field_22793.method_1727(motd) > maxW && motd.length() > 4)
                motd = motd.substring(0, motd.length() - 4) + "...";
            ctx.method_25303(field_22793, motd, tx, y + 33, 0x778CD2FF);
        }

        // Ping - s.ping is long; -1 = not yet pinged
        int pingMs  = (int) s.field_3758;
        int pingCol = pingMs < 0   ? 0xFF888888
                    : pingMs < 80  ? 0xFF4CFA87
                    : pingMs < 150 ? 0xFFFACC4C : 0xFFFA6C4C;
        String pingStr = pingMs < 0 ? "..." : pingMs + "ms";
        int pingX = x + w - 95;
        SkyzRenderHelper.fillRect(ctx, pingX + 5, y + 12, 8, 8, pingCol);
        ctx.method_25303(field_22793, pingStr, pingX + 16, y + 13, pingCol);

        if (s.field_3753 != null && !s.field_3753.getString().isEmpty())
            ctx.method_25303(field_22793, s.field_3753.getString(), pingX, y + 26, 0x4D8CD2FF);

        // Connect button
        int bx = x + w - 62, by = y + (h - 18) / 2;
        boolean bHov = mx >= bx && mx <= bx + 54 && my >= by && my <= by + 18;
        SkyzRenderHelper.fillPanel(ctx, bx, by, 54, 18,
                bHov ? 0x661E6EC8 : 0x441864A0, 0x558CD2FF);
        ctx.method_25300(field_22793, "Connect", bx + 27, by + 5,
                bHov ? 0xFFFFFFFF : 0xCCDDFFFF);
    }

    private void drawDirectConnectOverlay(class_332 ctx, int mx, int my) {
        ctx.method_25294(0, 0, field_22789, field_22790, 0xCC050F2A);
        int bw = 320, bh = 110, bx = (field_22789 - bw) / 2, by = (field_22790 - bh) / 2;
        SkyzRenderHelper.fillPanel(ctx, bx, by, bw, bh, 0xEE071830, 0x778CD2FF);
        ctx.method_25300(field_22793, "Direct Connect", field_22789 / 2, by + 14, 0xFFF0F8FF);
        ctx.method_25303(field_22793, "Server address:", bx + 14, by + 30, SkyzColors.TEXT_MUTED);

        SkyzRenderHelper.fillPanel(ctx, bx + 14, by + 42, bw - 28, 22, 0x55091E46, 0x558CD2FF);
        String addr = directAddr.isEmpty() ? "play.example.com" : directAddr + "\u258D";
        ctx.method_25303(field_22793, addr, bx + 20, by + 49,
                directAddr.isEmpty() ? 0x388CD2FF : SkyzColors.TEXT_PRIMARY);

        int btnY = by + bh - 30;
        boolean cnHov = mx >= bx+14 && mx <= bx+144 && my >= btnY && my <= btnY+22;
        boolean caHov = mx >= bx+bw-144 && mx <= bx+bw-14 && my >= btnY && my <= btnY+22;
        SkyzRenderHelper.fillPanel(ctx, bx+14,     btnY, 130, 22, cnHov?0x661E6EC8:0x551864A0, 0x558CD2FF);
        SkyzRenderHelper.fillPanel(ctx, bx+bw-144, btnY, 130, 22, caHov?0x66143C6E:0x33091E46, 0x338CD2FF);
        ctx.method_25300(field_22793, "Connect", bx+79,    btnY+7, cnHov?0xFFFFFFFF:0xCCDDFFFF);
        ctx.method_25300(field_22793, "Cancel",  bx+bw-79, btnY+7, caHov?0xFFFFFFFF:SkyzColors.TEXT_MUTED);
    }

    // Connects to a server \u2014 passing THIS as parent so disconnect returns here
    private void doConnect(class_642 info) {
        pinger.method_3004();
        class_412.method_36877(this, mc, class_639.method_2950(info.field_3761), info, false, null);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (super.method_25402(click, doubled)) return true;
        double mx = click.comp_4798(), my = click.comp_4799();

        if (connectingDirect) {
            int bw = 320, bh = 110, bx = (field_22789-bw)/2, by = (field_22790-bh)/2;
            int btnY = by + bh - 30;
            if (mx >= bx+14 && mx <= bx+144 && my >= btnY && my <= btnY+22) {
                if (!directAddr.isEmpty()) {
                    connectingDirect = false;
                    doConnect(new class_642(directAddr, directAddr, class_642.class_8678.field_45611));
                }
            } else if (mx >= bx+bw-144 && my >= btnY && my <= btnY+22) {
                connectingDirect = false;
            }
            return true;
        }

        // Filters
        int ty = NAV_H + 4, sX = PAD + 238;
        int sW = Math.min(200, field_22789 - sX - PAD - 80);
        int fx = sX + sW + 8;
        for (String[] f : new String[][]{{"all","All"},{"fav","Favourites"}}) {
            int fw = field_22793.method_1727(f[1]) + 14;
            if (mx >= fx && mx <= fx+fw && my >= ty && my <= ty+20) {
                activeFilter = f[0]; scrollOffset = 0; return true;
            }
            fx += fw + 4;
        }

        // Cards
        List<class_642> servers = getFiltered();
        int listTop = NAV_H + TOOLBAR_H + 8;
        int cardW   = field_22789 - PAD * 2;
        int y       = listTop - scrollOffset;
        for (class_642 s : servers) {
            int bx = PAD + cardW - 62, by = y + (CARD_H - 18) / 2;
            if (mx >= bx && mx <= bx+54 && my >= by && my <= by+18) {
                doConnect(s); return true;
            }
            y += CARD_H + CARD_GAP;
        }
        return false;
    }

    @Override
    public boolean method_25401(double mx, double my, double h, double v) {
        int listH  = field_22790 - (NAV_H + TOOLBAR_H + 8) - 8;
        int totalH = getFiltered().size() * (CARD_H + CARD_GAP);
        scrollOffset = (int) Math.max(0, Math.min(Math.max(0, totalH-listH), scrollOffset - v*16));
        return true;
    }

    @Override
    public boolean method_25400(class_11905 input) {
        String s = input.method_74226();
        if (connectingDirect) { if (!s.isEmpty()) directAddr += s; }
        else if (!s.isEmpty()) { searchQuery += s; scrollOffset = 0; }
        return true;
    }

    @Override
    public boolean method_25404(class_11908 input) {
        int key = input.method_74228();
        if (key == 259) { // BACKSPACE
            if (connectingDirect) { if (!directAddr.isEmpty()) directAddr = directAddr.substring(0, directAddr.length()-1); }
            else if (!searchQuery.isEmpty()) { searchQuery = searchQuery.substring(0, searchQuery.length()-1); scrollOffset = 0; }
            return true;
        }
        if (key == 256 && connectingDirect) { connectingDirect = false; return true; }
        if ((key == 257 || key == 335) && connectingDirect && !directAddr.isEmpty()) {
            connectingDirect = false;
            doConnect(new class_642(directAddr, directAddr, class_642.class_8678.field_45611));
            return true;
        }
        return super.method_25404(input);
    }

    @Override public boolean method_25421() { return false; }

    private List<class_642> getFiltered() {
        String q = searchQuery.toLowerCase();
        List<class_642> out = new ArrayList<>();
        for (int i = 0; i < serverList.method_2984(); i++) {
            class_642 s = serverList.method_2982(i);
            if (!q.isEmpty() && !s.field_3752.toLowerCase().contains(q) && !s.field_3761.toLowerCase().contains(q)) continue;
            out.add(s);
        }
        return out;
    }
}
