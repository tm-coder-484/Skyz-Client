package net.skyz.client.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1959;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import net.minecraft.class_5321;
import net.minecraft.class_9779;
import net.skyz.client.util.SkyzClientState;
import net.skyz.client.util.SkyzHudState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Optional;

@Mixin(class_329.class)
public class InGameHudMixin {

    // Session timer
    private static long sessionStart = 0;

    @Inject(method = "render", at = @At("TAIL"))
    private void skyz$render(class_332 ctx, class_9779 tick, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        int W = ctx.method_51421();
        int H = ctx.method_51443();
        SkyzHudState.initDefaults(W, H);

        if (sessionStart == 0) sessionStart = System.currentTimeMillis();
        net.skyz.client.util.SkyzClientState.updateCps();

        for (SkyzHudState.HudElementState el : SkyzHudState.ELEMENTS) {
            if (!el.enabled) continue;
            renderElement(ctx, client, el, W, H);
        }
    }

    private void renderElement(class_332 ctx, class_310 client,
                               SkyzHudState.HudElementState el, int W, int H) {
        // Keystrokes and custom crosshair have special rendering
        switch (el.name) {
            case "Keystrokes"      -> { renderKeystrokes(ctx, client, el); return; }
            case "Potion Effects"  -> { renderPotions(ctx, client, el); return; }
            case "Custom Crosshair"-> { renderCrosshair(ctx, el, W, H); return; }
            case "Enemy Info"      -> { renderEnemyInfo(ctx, client, el); return; }
            case "Nearby Players"  -> { renderNearbyPlayers(ctx, client, el); return; }
            case "TNT Timer"       -> { renderTntTimer(ctx, client, el); return; }
            case "Compass"         -> { renderCompass(ctx, client, el, W); return; }
            case "Minimap"         -> { renderMinimap(ctx, client, el); return; }
        }

        // Standard pill background
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0xAA000000);
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+1, 0x668CD2FF);
        int ty = el.y + (el.h-8)/2;
        var tr = client.field_1772;

        switch (el.name) {
            case "FPS Counter" -> {
                int f = client.method_47599();
                ctx.method_25303(tr, f+" FPS", el.x+4, ty,
                        f>=60 ? 0xFF4CFA87 : f>=30 ? 0xFFFACC4C : 0xFFFA6C4C);
            }
            case "CPS Counter" -> {
                ctx.method_25303(tr, SkyzClientState.cps+" CPS", el.x+4, ty, 0xCCFFFFFF);
            }
            case "Coordinates" -> {
                ctx.method_25303(tr, String.format("%.0f / %.0f / %.0f",
                        client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()),
                        el.x+4, ty, 0xCCFFFFFF);
            }
            case "Biome Display" -> {
                String biome = getBiomeName(client);
                ctx.method_25303(tr, "\uD83C\uDF3F "+biome, el.x+4, ty, 0xCCB0F0B0);
            }
            case "Speed Meter" -> {
                double dx = client.field_1724.method_23317() - client.field_1724.field_6038;
                double dz = client.field_1724.method_23321() - client.field_1724.field_5989;
                double spd = Math.sqrt(dx*dx+dz*dz)*20;
                ctx.method_25303(tr, String.format("\u26A1 %.1f b/s", spd), el.x+4, ty,
                        spd>5.6 ? 0xFF4CFA87 : spd>4.3 ? 0xFFFACC4C : 0xFFFFFFFF);
            }
            case "Ping Display" -> {
                int ping = -1;
                if (client.method_1542()) {
                    ping = 0; // local
                } else {
                    try {
                        var net = client.method_1562();
                        if (net != null) {
                            // Try by game profile name first (more reliable than UUID in some versions)
                            String name = client.field_1724.method_5477().getString();
                            for (var entry : net.method_2880()) {
                                if (entry.method_2966().name().equals(name)) {
                                    ping = entry.method_2959();
                                    break;
                                }
                            }
                        }
                    } catch (Exception ignored) {}
                }
                String pingStr = client.method_1542() ? "LAN"
                               : ping < 0 ? "???" : ping + "ms";
                int pingCol = client.method_1542() ? 0xFF4CFA87
                            : ping < 0 ? 0xFF888888
                            : ping < 80 ? 0xFF4CFA87 : ping < 150 ? 0xFFFACC4C : 0xFFFA6C4C;
                ctx.method_25303(tr, "\uD83D\uDCE1 " + pingStr, el.x+4, ty, pingCol);
            }
            case "Reach Display" -> {
                // Show reach distance, turns green when targeting entity
                boolean targeting = client.field_1765 != null &&
                        client.field_1765.method_17783() == class_239.class_240.field_1331;
                String reachStr = "\uD83C\uDFAF 3.0m";
                ctx.method_25303(tr, reachStr, el.x+4, ty, targeting ? 0xFF4CFA87 : 0xFFFFFFFF);
            }
            case "Memory Usage" -> {
                Runtime rt = Runtime.getRuntime();
                long used = (rt.totalMemory()-rt.freeMemory())/1048576;
                long max  = rt.maxMemory()/1048576;
                int pct = (int)(used*100/max);
                drawBar(ctx, el, pct, 0xCC2A7ACA, 0xFFAADDFF, "\uD83D\uDDA5 "+used+"MB", tr);
            }
            case "Entity Count" -> {
                int count = 0;
                for (class_1297 e : client.field_1687.method_18112()) count++;
                ctx.method_25303(tr, "\uD83D\uDC7E "+count+" entities", el.x+4, ty, 0xCCFFDDAA);
            }
            case "Session Timer" -> {
                long secs = (System.currentTimeMillis()-sessionStart)/1000;
                ctx.method_25303(tr, String.format("\u23F1 %d:%02d:%02d",
                        secs/3600, (secs%3600)/60, secs%60), el.x+4, ty, 0xCCDDDDFF);
            }
            case "Block Info" -> {
                String info = "Air";
                if (client.field_1765 != null &&
                        client.field_1765.method_17783() == class_239.class_240.field_1332) {
                    var bhr = (net.minecraft.class_3965) client.field_1765;
                    var state = client.field_1687.method_8320(bhr.method_17777());
                    if (!state.method_26215()) {
                        String raw = net.minecraft.class_7923.field_41175
                                .method_10221(state.method_26204()).method_12832().replace('_',' ');
                        info = raw.substring(0,1).toUpperCase()+raw.substring(1);
                    }
                }
                ctx.method_25303(tr, "\uD83E\uDDF1 "+info, el.x+4, ty, 0xCCFFFFDD);
            }
            case "Health Bar" -> {
                float hp = client.field_1724.method_6032(), maxHp = client.field_1724.method_6063();
                drawBar(ctx, el, (int)(hp/maxHp*100), 0xCCE03030, 0xFFFF8888,
                        "\u2764 "+(int)hp+"/"+(int)maxHp, tr);
            }
            case "Hunger Bar" -> {
                int food = client.field_1724.method_7344().method_7586();
                drawBar(ctx, el, food*5, 0xCCE08030, 0xFFFFBB66, "\uD83C\uDF56 "+food+"/20", tr);
            }
            case "Saturation Bar" -> {
                float sat = client.field_1724.method_7344().method_7589();
                drawBar(ctx, el, (int)(sat/20*100), 0xCCFFD700, 0xFFFFE866,
                        "\u2728 "+String.format("%.1f",sat), tr);
            }
            case "Armor Bar" -> {
                int armor = client.field_1724.method_6096();
                drawBar(ctx, el, armor*5, 0xCCAAAAAA, 0xFFCCCCCC, "\uD83D\uDEE1 "+armor+"/20", tr);
            }
            case "Tool Durability" -> {
                class_1799 tool = client.field_1724.method_6047();
                if (!tool.method_7960() && tool.method_7963()) {
                    int dur = tool.method_7936()-tool.method_7919(), max = tool.method_7936();
                    int pct = max>0 ? dur*100/max : 0;
                    drawBar(ctx, el, pct, 0xCC3A9A3A, 0xFF80FF80,
                            "\u26CF "+dur+"/"+max, tr);
                } else {
                    ctx.method_25303(tr, "\u26CF No tool", el.x+4, ty, 0x448CD2FF);
                }
            }
            case "Helmet Durability"     -> renderArmorSlot(ctx, client, el, net.minecraft.class_1304.field_6169,  "\u26D1");
            case "Chestplate Durability" -> renderArmorSlot(ctx, client, el, net.minecraft.class_1304.field_6174, "\uD83E\uDDF2");
            case "Leggings Durability"   -> renderArmorSlot(ctx, client, el, net.minecraft.class_1304.field_6172,  "\uD83D\uDC56");
            case "Boots Durability"      -> renderArmorSlot(ctx, client, el, net.minecraft.class_1304.field_6166,  "\uD83D\uDC62");
            case "Attack Cooldown" -> {
                float cooldown = client.field_1724.method_7261(0f);
                int pct = (int)(cooldown*100);
                ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0x55000000);
                ctx.method_25294(el.x, el.y, el.x+(int)(el.w*cooldown), el.y+el.h,
                        pct>=100 ? 0xCCFFAA00 : 0xCC884400);
            }
            case "Combo Counter" -> {
                int combo = net.skyz.client.util.SkyzClientState.comboCount;
                if (combo > 0) {
                    // Big centered combo display
                    ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0xAA000000);
                    int col = combo>=10?0xFFFF4444:combo>=5?0xFFFFAA00:0xFFFFFFFF;
                    String comboStr = combo + " combo";
                    ctx.method_25300(tr, comboStr, el.x+el.w/2, el.y+(el.h-8)/2, col);
                }
            }
            case "Totem Pop Counter" -> {
                int pops = net.skyz.client.util.SkyzClientState.totemPops;
                ctx.method_25303(tr, "\uD83C\uDF3C Totems: " + pops, el.x+4, ty, 0xFF88FF88);
            }
            default -> ctx.method_25303(tr, el.icon+" "+el.name, el.x+4, ty, 0x88FFFFFF);
        }
    }

    private void drawBar(class_332 ctx, SkyzHudState.HudElementState el,
                         int pct, int barColor, int textColor, String label,
                         net.minecraft.class_327 tr) {
        int bx = el.x+4, by = el.y+el.h-4, bw = el.w-8;
        ctx.method_25294(bx, by, bx+bw, by+3, 0x55333333);
        ctx.method_25294(bx, by, bx+Math.max(0, bw*pct/100), by+3, barColor);
        ctx.method_25303(tr, label, el.x+4, el.y+2, textColor);
    }

    private void renderTntTimer(class_332 ctx, class_310 client, SkyzHudState.HudElementState el) {
        List<class_1541> tnts = client.field_1687.method_8390(class_1541.class,
                client.field_1724.method_5829().method_1014(100), e -> true);
        if (tnts.isEmpty()) return;

        // Find closest lit TNT
        class_1541 closest = null;
        double minDist = Double.MAX_VALUE;
        for (class_1541 t : tnts) {
            double d = t.method_5858(client.field_1724);
            if (d < minDist) { minDist = d; closest = t; }
        }

        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0xCC440000);
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+1, 0xAAFF4400);
        var tr = client.field_1772;

        // getFuse() returns remaining fuse ticks
        if (closest != null) {
            int fuseTicks = closest.method_6969();
            float fuseSecs = fuseTicks / 20f;
            String timeStr = String.format("%.1fs", fuseSecs);
            ctx.method_25303(tr, "\uD83D\uDCA5 " + tnts.size() + " TNT \u00B7 " + timeStr,
                    el.x+4, el.y+(el.h-8)/2, fuseSecs < 1f ? 0xFFFF4444 : 0xFFFF9944);
        } else {
            ctx.method_25303(tr, "\uD83D\uDCA5 "+tnts.size()+" TNT",
                    el.x+4, el.y+(el.h-8)/2, 0xFFFFAA44);
        }
    }

    private void renderEnemyInfo(class_332 ctx, class_310 client, SkyzHudState.HudElementState el) {
        if (!(client.field_1765 instanceof class_3966 ehr)) return;
        class_1297 target = ehr.method_17782();
        if (!(target instanceof class_1309 living)) return;

        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0xAA000000);
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+1, 0x88FF4444);
        var tr = client.field_1772;
        int y = el.y+4;

        String name = living.method_5476().getString();
        ctx.method_25303(tr, "\uD83D\uDC80 "+name, el.x+4, y, 0xFFFF8888); y+=12;

        float hp = living.method_6032(), maxHp = living.method_6063();
        int bw = el.w-8;
        ctx.method_25294(el.x+4, y, el.x+4+bw, y+6, 0x55333333);
        ctx.method_25294(el.x+4, y, el.x+4+(int)(bw*hp/maxHp), y+6, 0xCCE03030);
        ctx.method_25303(tr, String.format("%.0f/%.0f HP",hp,maxHp), el.x+4, y+8, 0xFFFF9999); y+=20;

        int armor = living.method_6096();
        ctx.method_25303(tr, "\uD83D\uDEE1 "+armor+" armor", el.x+4, y, 0xFFCCCCCC); y+=12;

        if (living instanceof class_1657 p) {
            class_1799 held = p.method_6047();
            if (!held.method_7960()) {
                String itemName = held.method_7964().getString();
                ctx.method_25303(tr, "\u2694 "+itemName, el.x+4, y, 0xFFFFDD88);
            }
        }
    }

    private void renderNearbyPlayers(class_332 ctx, class_310 client, SkyzHudState.HudElementState el) {
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0xAA000000);
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+1, 0x888CD2FF);
        var tr = client.field_1772;
        int y = el.y+4;
        ctx.method_25303(tr, "\uD83D\uDC65 Nearby", el.x+4, y, 0xFF8CD2FF); y+=12;

        int count = 0;
        for (class_1657 p : client.field_1687.method_18456()) {
            if (p == client.field_1724) continue;
            double dist = p.method_5739(client.field_1724);
            if (dist > 64) continue;
            String line = p.method_5477().getString()+" "+Math.round(dist)+"m";
            ctx.method_25303(tr, line, el.x+4, y, 0xCCFFFFFF);
            y += 10;
            if (++count >= 6) break;
        }
        if (count == 0)
            ctx.method_25303(tr, "None nearby", el.x+4, y, 0x448CD2FF);
    }

    private void renderCompass(class_332 ctx, class_310 client, SkyzHudState.HudElementState el, int W) {
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0xAA000000);
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+1, 0x668CD2FF);
        var tr = client.field_1772;
        // Normalize yaw: MC yaw 0=south, -90=east, 90=west, 180/-180=north
        float yaw = ((client.field_1724.method_36454() % 360) + 360) % 360; // 0-360, 0=south
        // Cardinal direction label
        String dir;
        if (yaw < 22.5f || yaw >= 337.5f) dir = "S";
        else if (yaw < 67.5f)  dir = "SW";
        else if (yaw < 112.5f) dir = "W";
        else if (yaw < 157.5f) dir = "NW";
        else if (yaw < 202.5f) dir = "N";
        else if (yaw < 247.5f) dir = "NE";
        else if (yaw < 292.5f) dir = "E";
        else                   dir = "SE";
        // Scrolling compass strip — render chars N, NE, E, SE, S, SW, W, NW spaced out
        String strip = "N  NE  E  SE  S  SW  W  NW  N  NE  E";
        int stripW = tr.method_1727(strip);
        // offset so current direction centers in the element
        int offset = (int)(yaw / 360f * (stripW / 2)) % (stripW / 2);
        int cx = el.x + el.w/2;
        ctx.method_44379(el.x+1, el.y, el.x+el.w-1, el.y+el.h);
        ctx.method_25303(tr, strip, cx - offset - stripW/4, el.y+3, 0xCCFFFFFF);
        ctx.method_44380();
        // Center tick
        ctx.method_25294(cx-1, el.y, cx+1, el.y+el.h, 0xCCFF4444);
        // Direction label at right edge
        ctx.method_25303(tr, dir, el.x+el.w-tr.method_1727(dir)-4, el.y+3, 0xFF8CD2FF);
    }

    private void renderPotions(class_332 ctx, class_310 client, SkyzHudState.HudElementState el) {
        var effects = client.field_1724.method_6026();
        if (effects.isEmpty()) return;
        int iy = el.y;
        for (var effect : effects) {
            ctx.method_25294(el.x, iy, el.x+el.w, iy+18, 0xAA000000);
            ctx.method_25294(el.x, iy, el.x+el.w, iy+1, 0x668CD2FF);
            String name = "?";
            var id = net.minecraft.class_7923.field_41174.method_10221(effect.method_5579().comp_349());
            if (id != null) { name = id.method_12832().replace('_',' '); name = name.substring(0,1).toUpperCase()+name.substring(1); }
            int dur = effect.method_5584()/20;
            ctx.method_25303(client.field_1772,
                    name+" "+(dur>60?dur/60+"m":dur+"s"), el.x+4, iy+5, 0xCCFFFFFF);
            iy += 20;
            if (iy > el.y+el.h) break;
        }
    }

    private void renderCrosshair(class_332 ctx, SkyzHudState.HudElementState el, int W, int H) {
        int cx = el.x+el.w/2, cy = el.y+el.h/2, size = 6;
        ctx.method_25294(cx-size, cy-1, cx+size, cy+1, 0xCCFFFFFF);
        ctx.method_25294(cx-1, cy-size, cx+1, cy+size, 0xCCFFFFFF);
    }

    private void renderKeystrokes(class_332 ctx, class_310 client, SkyzHudState.HudElementState el) {
        var opts = client.field_1690;
        int kw=22, kh=18, gap=2;
        drawKey(ctx, client, "W",  el.x+kw+gap,      el.y+2,           kw, kh, opts.field_1894.method_1434());
        drawKey(ctx, client, "A",  el.x+2,            el.y+kh+gap+2,    kw, kh, opts.field_1913.method_1434());
        drawKey(ctx, client, "S",  el.x+kw+gap,       el.y+kh+gap+2,    kw, kh, opts.field_1881.method_1434());
        drawKey(ctx, client, "D",  el.x+(kw+gap)*2,   el.y+kh+gap+2,    kw, kh, opts.field_1849.method_1434());
        drawKey(ctx, client, "",   el.x+2,             el.y+(kh+gap)*2+2,kw*3+gap*2, kh, opts.field_1903.method_1434());
    }

    private void drawKey(class_332 ctx, class_310 client, String label,
                         int x, int y, int w, int h, boolean pressed) {
        ctx.method_25294(x,y,x+w,y+h, pressed?0xCC2A5A8A:0x88151515);
        ctx.method_25294(x,y,x+w,y+1, pressed?0x884AB8F0:0x44888888);
        ctx.method_25294(x,y+h-1,x+w,y+h, pressed?0x444AB8F0:0x22888888);
        if (!label.isBlank())
            ctx.method_25300(client.field_1772, label,
                    x+w/2, y+(h-8)/2, pressed?0xFFFFFFFF:0x88AAAAAA);
    }

    private void renderArmorSlot(class_332 ctx, class_310 client,
                                  net.skyz.client.util.SkyzHudState.HudElementState el,
                                  net.minecraft.class_1304 slot, String icon) {
        net.minecraft.class_1799 s = client.field_1724.method_6118(slot);
        var tr = client.field_1772;
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+el.h, 0xAA000000);
        ctx.method_25294(el.x, el.y, el.x+el.w, el.y+1, 0x668CD2FF);
        int ty = el.y + (el.h-8)/2;
        if (s.method_7960()) {
            ctx.method_25303(tr, icon+" None", el.x+4, ty, 0x338CD2FF);
        } else if (s.method_7963()) {
            int dur = s.method_7936()-s.method_7919(), max = s.method_7936();
            int pct = max>0?dur*100/max:0;
            int col = pct>60?0xFF4CFA87:pct>30?0xFFFACC4C:0xFFFA6C4C;
            drawBar(ctx, el, pct, col&0x00FFFFFF|0xCC000000, col, icon+" "+dur+"/"+max, tr);
        } else {
            ctx.method_25303(tr, icon+" "+s.method_7964().getString(), el.x+4, ty, 0xCCFFFFFF);
        }
    }

    private void renderMinimap(class_332 ctx, class_310 client, net.skyz.client.util.SkyzHudState.HudElementState el) {
        int mx = el.x, my = el.y, mw = el.w, mh = el.h;
        // Background + border
        ctx.method_25294(mx, my, mx+mw, my+mh, 0xDD000000);
        ctx.method_25294(mx, my, mx+mw, my+1, 0x888CD2FF);
        ctx.method_25294(mx, my+mh-1, mx+mw, my+mh, 0x888CD2FF);
        ctx.method_25294(mx, my, mx+1, my+mh, 0x888CD2FF);
        ctx.method_25294(mx+mw-1, my, mx+mw, my+mh, 0x888CD2FF);

        int cx = mx + mw/2, cy = my + mh/2;
        int range = 32; // blocks shown on minimap

        // Draw nearby entities as colored dots
        try {
            for (net.minecraft.class_1297 e : client.field_1687.method_18112()) {
                if (e == client.field_1724) continue;
                double ex = e.method_23317() - client.field_1724.method_23317();
                double ez = e.method_23321() - client.field_1724.method_23321();
                if (Math.abs(ex) > range || Math.abs(ez) > range) continue;
                int dotX = cx + (int)(ex * (mw/2-2) / range);
                int dotY = cy + (int)(ez * (mh/2-2) / range);
                int col = e instanceof net.minecraft.class_1657 ? 0xFFFFFF44
                         : e instanceof net.minecraft.class_1588   ? 0xFFFF4444
                         : 0xFF44FF44;
                ctx.method_25294(dotX-1, dotY-1, dotX+1, dotY+1, col);
            }
        } catch (Exception ignored) {}

        // Player dot (center, white) with direction arrow
        ctx.method_25294(cx-1, cy-1, cx+1, cy+1, 0xFFFFFFFF);
        // Direction indicator
        float yaw = ((client.field_1724.method_36454() % 360) + 360) % 360;
        int ax = cx + (int)(Math.sin(Math.toRadians(yaw)) * 5);
        int ay = cy - (int)(Math.cos(Math.toRadians(yaw)) * 5);
        ctx.method_25294(ax-1, ay-1, ax+1, ay+1, 0xFFFF4444);

        // "Minimap" label
        ctx.method_25303(client.field_1772, "N", cx - client.field_1772.method_1727("N")/2, my+3, 0x888CD2FF);
    }

    private String getBiomeName(class_310 client) {
        try {
            Optional<class_5321<class_1959>> key = client.field_1687
                    .method_23753(client.field_1724.method_24515()).method_40230();
            if (key.isPresent()) {
                String raw = key.get().method_29177().method_12832();
                return raw.substring(0,1).toUpperCase()+raw.substring(1).replace('_',' ');
            }
        } catch (Exception ignored) {}
        return "Unknown";
    }
}