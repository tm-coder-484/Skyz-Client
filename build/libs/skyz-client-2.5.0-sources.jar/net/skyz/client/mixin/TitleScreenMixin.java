package net.skyz.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_442;
import net.skyz.client.screen.SkyzTitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces vanilla TitleScreen with SkyzTitleScreen.
 */
@Mixin(class_442.class)
public class TitleScreenMixin {

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void skyz$replaceTitleScreen(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (!(client.field_1755 instanceof SkyzTitleScreen)) {
            client.method_1507(new SkyzTitleScreen());
            ci.cancel();
        }
    }
}
